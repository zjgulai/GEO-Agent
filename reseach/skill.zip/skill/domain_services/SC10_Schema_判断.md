# SC10｜Schema 判断

**定位**：统一 Structured Data 类型、字段、可见内容一致性与验证逻辑。

**Owner**：`11`  
**执行介质**：`retrieval+rules+LLM`

## 输入
- `page_snapshot`
- `entity/page_type`

## 输出
- `schema_findings`
- `schema_requirements`

## 复用模块
`01`, `06`, `09`, `11`, `12`, `13`, `16`, `17`
