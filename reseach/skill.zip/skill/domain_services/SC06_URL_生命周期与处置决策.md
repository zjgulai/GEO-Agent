# SC06｜URL 生命周期与处置决策

**定位**：对 URL 形成 retain/update/merge/canonical/noindex/301/410 等动作，并记录业务价值、意图、索引状态与依赖。

**Owner**：`shared`  
**执行介质**：`rules+LLM`

## 输入
- `url_state`
- `intent`
- `value`
- `duplication`
- `replacement`

## 输出
- `url_action`
- `target_url`
- `dependencies`

## 复用模块
`06`, `07`, `12`, `13`, `15`, `17`
