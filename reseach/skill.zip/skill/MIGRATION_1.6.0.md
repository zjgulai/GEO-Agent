# 1.6.0 迁移说明

本版本从冻结 1.5.0 的162个文件复制，修复范围仅 S01–S03。旧 release、Round 1 Benchmark 的材料、18个答案及全部评估/裁决保持历史状态。不要用本版本重算并覆盖旧轮结果。SEO Core、canonical_v1_5 profile、六个 canonical KPI 集合及四级 attribution 枚举保持不变。

## S01：brand_mention_rate 的含义与历史值

1.6.0 的 `brand_mention_rate` = 有效观测中有 mention 唯一解析到 `own_entity` 的 distinct observation_id 数 / 有效 distinct observation_id 数。归一化别名必须来自注册实体表；只提竞品、present=true 或重复别名不能增加自有分子。计算去重不能代替采集校验：原生 observation validator 仍拒绝重复 ID 和错误实体解析。

1.5.0 的文档声明 own_entity，但代码/fixture 使用 `brand_mention.present`，会计入 competitor-only。旧报告必须保留“1.5.0 实际 present 口径”的解释；缺原始观测时不得把旧值推断为自有值。若有原始证据，可单独输出标注1.6.0的新报告；不能将口径变化称为真实业务增长。

本版本 phase1 KPI fixture 从9/14=0.6429改为4/14=0.2857。竞品份额保持11/15=0.7333，且其 evidence 保留全部9个有注册实体提及的有效观测，不受自有分子缩小影响。

Intent 分组从真实 `prompt.metadata.intent` 重建：commercial 6条、comparison 3条、informational 3条、troubleshooting 2条，合计14。自有提及率分别为2/6、1/3、0/3、1/2；旧 fixture 的分组遗漏/错分不能继续继承。每组按原有5条有效观测阈值标记 ok 或 small_sample，数值与成员均由 validator 重算校验。

`own_brand_mention_rate` 保留为 GEO-06 兼容名称，复用 canonical 的同一实现、有效样本数和 contributing observation IDs；不是新增 canonical KPI。新报告优先用 canonical 名称，若两个名称并列，数值必须一致，不能将其当作两个独立效果信号。旧 own_brand 自有含义不变；旧 brand 与新 brand 不可无版本说明直接比较。

## S02：可空值与窗口可比性

Schema 继续允许 null。窗口不可比时可以保留单窗数值，但比较 `delta`/`direction` 必须 null，metric status 为 partial/unavailable，整体为 inconclusive。更新后的两个不可比 fixture 保留原 baseline/post 数值，只清空效果字段并标 partial。

可比且 status=ok 要有数值 baseline/post/delta。partial 可保留缺值，未形成比较时 delta/direction 为 null；unavailable 必须有原因，不得声明效果。任何实际数值比较仍重算差值与方向，包括 guardrail；非法组合返回 validation errors，不能抛出 None 算术异常。不可用护栏不会当零，也不能支持 success。

guardrail 的原有 arm/scope 解释保持：通用差值/方向会校验，但不把治疗组 per-window canonical rate 强套到对照组护栏。`not_established` attribution 表示问题仍待 follow-up；未新增枚举、未修改归因门槛。

## S03：实现状态与运行可用性

canonical ownership registry 中 GEO-05/06 保持 active。当前契约/指引、taxonomy、validator 和 fixture builder 不再把它们一律视为未实现。Owner 可用时 open；真实不可用时 deferred，源模块不得越权接管目标模块的最终判断。

`validate_authority_diagnoses(..., skill_root, runtime_context=None)` 保留旧调用形式。未传 context 时仅按包内注册模块均可用进行产物校验，不证明真实环境可用。运行级调用应传既有格式：

```json
{"execution_context":{"availability":{"available_modules":["geo_05"],"unavailable_modules":["geo_06"],"required_capability_scope":[]}}}
```

每个需要 handoff 的 owner 必须在 available/unavailable 中恰好一处；未知 owner、矛盾可用性、owner/domain 不匹配、错误状态均拒绝。通过 `validate_geo05(skill_root, artifacts)` 时将 context 放在 `artifacts["runtime_context"]`，wrapper 会转交。不提供 context 时，原先基于“GEO-06 未实现”的 deferred 记录会被拒绝；真实 unavailable 的旧记录需携带真实 runtime availability。

Authority fixture builder 支持 `owner_available=False` 生成 deferred；默认对应可用环境生成 open。canonical registry 不降级，旧修订的历史章节不改写。

## 验证与后续

执行 `python tests/run_geo_regression.py` 与 `python tests/test_skill_repairs.py -v`。release_build.py 已将新测试加入发布门禁。原78项的下一版本副本保留全部测试场景与负例；仅更新受自有口径、实际分组样本和当前 active 描述直接影响的断言，旧冻结测试没有改动。

1.6.0 正式版从 1.6.0-rc1 晋升，业务逻辑保持一致。S01 已获 Fresh-Agent differential holdout 完整支持；S02 nullable 修复获得完整支持，LP-G 已正式裁定为 Benchmark/spec interpretation issue（可接受的分层表达）；S03 direct runtime-aware handoff 机制已验证，但未证明 Fresh-Agent 行为收益提升。旧 V2 冻结评分不回写，不宣称三项都带来 Agent 表现提升。发布验证范围见 [正式发布说明](RELEASE_NOTES_1.6.0.md)。RA-01 多窗口规则闭合、not_established 表示、格式/引用交付、未提示限制发现、macOS native certification 均未处理；没有开发 GEO-07。
