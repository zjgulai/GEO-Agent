# SEO Skill V1.4 — 最小编排核心（Minimal Orchestration Core）

V1.4 使用 3 个阶段和 5 类最小对象。

## 阶段 A — 计划（Plan）
输出一个 `Plan`：
- `primary_route`
- `modules`
- `context_used` / `context_excluded`
- 可选 `reason`

规则：先识别外层任务；技术信号只追加 specialist，不覆盖明确的 primary route。

## 阶段 B — 推理（Reason）
Specialist 产生 `Evidence`，所有需要留痕的关键判断统一写为 `Decision`：
- `type`: claim / owner / dedup / dependency / forecast / portfolio / context / other
- `subject`
- `decision`
- `reason`
- 可选 `evidence_ids`

跨 Owner 直接写 `Handoff`，不再要求多层升级/归属中间对象后才能产生 Handoff。

## 阶段 C — 校验（Validate）
只验证真正决定专业可用性的 invariants：
- Route / required specialist 是否合理
- 跨 Owner 是否交接
- confirmed claim 是否有证据
- Dedup 是否按 root cause 而非 symptom
- blocker 是否改变 executable
- global priority 是否由 19 写
- 缺核心输入时是否避免 fake precision
- excluded context 是否未被使用
- JSON 是否可解析

格式完整度单独作为 Trace Quality，不与 Semantic PASS 混为一谈。
