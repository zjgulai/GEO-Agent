# Release Notes — 1.6.0

发布日期：2026-10-10。渠道：stable。由 1.6.0-rc1 正式晋升。

本版保持 rc1 的 S01/S02/S03 修复代码、schema、taxonomy、validator、fixture 与测试语义不变。晋升只更新版本标识、发布元数据、文档与迁移入口。canonical profile 仍为 `canonical_v1_5`，六个 canonical KPI 与归因层级不变。

## 修复与验证结论

- **S01：Fresh-Agent differential holdout 完整支持。** `brand_mention_rate = own_entity`，仅统计有效观测中解析到自有实体的 distinct observation IDs。V2 D01 为 baseline 0/3 → candidate 3/3 达标，竞品证据与 intent 分组保留。
- **S02：nullable 修复获得完整支持。** 不可比窗口保留合法单窗读数，delta/direction 为 null，不 crash；numeric mismatch 仍拒绝。LP-G 已裁定为 **Benchmark/spec interpretation issue（BSPEC-LPG-01）**：主指标描述性 improved 可与 success=false/null、guardrail unknown 分层表达，不是整体成功或因果主张。旧 V2 的 3/3 部分达标评分不回写；完整支持来自独立正式 adjudication。
- **S03：direct runtime-aware handoff 机制已验证，但未证明 Fresh-Agent 行为收益提升。** GEO-05→GEO-06 原生动态交接接受 available/open 与 unavailable/deferred，并拒绝错误状态；GEO-04/05 active Owner 契约保持一致。V2 两个 runtime 条件两版本均 3/3 达标；baseline 合法 staged workaround 是正确业务替代。GEO-04 局部 validator 的既有状态校验覆盖边界没有在本次晋升中改动。

**不宣称“三项都带来 Agent 表现提升”。** 修复正确性、原生执行机制、Fresh-Agent 行为收益分别报告。

## 迁移

读取 [MIGRATION_1.6.0.md](MIGRATION_1.6.0.md)。旧 1.5.0 present 口径报告不覆盖、不伪装为自有值，不把口径变化描述为业务增长。运行级 authority validator 应传入真实 runtime availability；未传 context 的兼容调用不证明真实环境可用。

## 正式发布验证

使用原样发布流程重新执行 GEO 78 项、targeted repair 30 项、release engineering 12 项、SEO Core/GEO contract、canonical 正负例与最终 clean ZIP audit。正式发布报告另记录实际结果和 ZIP SHA-256；解包到含 Unicode 与空格的新路径，核验归档成员及原生 CLI/canonical 可迁移性。历史 Benchmark、Golden/Rubric、V2 sessions、adjudication 和 rc1 发布包保持原样。

本版本没有新增 GEO-07 或其他功能。macOS native certification 等既有后续项未在 Windows 路径检查中代替验证。

## 证据来源

晋升结论依据项目既有 `DIFFERENTIAL_HOLDOUT_V2.md`、`FINAL_REPAIR_ADJUDICATION.md`、`SKILL_REPAIR_REPORT.md`。这些报告和私有实验材料不打入 Skill ZIP；发布元数据记录版本与 rc1 来源，发布报告提供本次 gate 和保护核验结果。
