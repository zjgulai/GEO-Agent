# GEO-06 度量方法（度量、增长与实验闭环方法）

**定位**：GEO-01～03 回答"发生了什么"，GEO-04 回答"为什么没被引用"，GEO-05 回答"实体与权威如何"，
GEO-06 回答"**优化后能不能验证效果、是否值得继续投入**"。
**机器可读 SSOT**：`GEO_06_MEASUREMENT_TAXONOMY.yaml`、`GEO_06_DIAGNOSIS.yaml`、
`geo/schemas/geo_measurement_schema.json`、`geo/schemas/geo_intervention_priority_schema.json`。
本文件只说明**怎么度量**，不重复定义阈值与口径。

---

## 1. 认识论边界

GEO-06 只做**效果判断**，不做因果证明，除非实验设计成立。四件事必须分清：

| 概念 | 含义 | 允许的表述 |
|---|---|---|
| `observation_change` | 只报告数值差异 | 指标从 A 变为 B |
| `association` | 变化与干预时间相关，无对照 | 可能与该干预相关 |
| `experimental_evidence` | 有对照组且方向一致 | 处理组相对对照组出现方向一致的差异 |
| `causal_claim` | 对照 + 混淆因素已处理 + 跨窗口重复 | 该干预是该变化的原因 |

**归因层级由设计决定，不由指标变化幅度决定。** 指标涨 20 个百分点但无对照组，仍然只能是 `association`。

## 2. 什么情况可以下变化结论

一次合法的变化判断必须同时满足：

1. 两窗口在 `universe_id` / `universe_version` / `engine_id` / `surface_id` / `surface_type` / `market` / `locale` / `prompt_set` 上**全部同构**
2. 每窗口 `execution_status=ok` 的观测数 ≥ `min_observations_per_window`（5）
3. 主指标非 `unavailable`，且不是只由单条观测支撑
4. 观测执行失败的条数已单列

**不成立时**：输出 `inconclusive` + `unresolved_gaps`，confidence 只能是 `unresolved` 或 `low`。

## 3. 指标计算（不得自报算法）

指标值由校验器**重算**：复用 GEO-03 的 `citation_visibility_metrics(observations, universe)`，
再按窗口切片。因此 record 中的 `baseline_value` / `post_value` 必须与重算结果一致（容差 0.005），
`delta` 必须等于 `post - baseline`，`sample_size` 必须等于该窗口的 ok 观测数。

**失败观测不进入分子分母。**

## 4. 变化判断流程

```
1. 可比性检查   → 任一 mismatch ⇒ inconclusive
2. 样本量检查   → 任一窗口 < 5 ⇒ inconclusive
3. 指标可用性   → unavailable ⇒ inconclusive
4. materiality  → |Δ| < 0.05 ⇒ no_material_change
5. 方向判断     → Δ > 0 ⇒ improved（需要成功判据）; Δ < 0 ⇒ declined
6. 护栏复核     → 护栏恶化 ⇒ 降级 confidence / limitations；严重恶化 ⇒ inconclusive
```

**materiality 阈值是工程约定。** 它不是显著性检验，不得写成"统计显著"。

## 5. 无 control 时的写法

没有对照组时：

- `design_type` 只能是 `before_after_single_group`
- `attribution_level` 上限 `association`
- `confidence` 上限 `low`
- **不得**记录 `success = true`
- 表述必须是"该变化在干预之后出现"，不是"该干预导致"

如果需要因果主张，必须先构造对照：`holdout`（保留未处理的 prompt）、`matched_prompts`（匹配对照组）、
`untreated_engine`（同 prompt 在未干预引擎上）、或 `historical_series`（历史序列）。

## 6. 护栏交互

主指标改善但护栏恶化时**不得判成功**：

| 护栏触发 | 处理 |
|---|---|
| `error_observation_count` 上升 | instrument 恶化，降级并在 `limitations` 记录 |
| `own_domain_citation_rate` 未改善而 `brand_mention_rate` 上升 | 可能是幻觉式提及，必须记录并交 GEO-05 复核 |
| `visibility_stability` 下降 | 波动过大，判 `inconclusive` |
| `competitor_mention_share` 同时上升 | 自有改善被竞品抵消，必须同句说明 |

## 7. Intervention 优先级排序

**字典序，不是加权求和**：

```
evidence_strength → expected_impact → measurement_feasibility → implementation_cost
```

每个维度只给离散等级。校验器会**验证排序是否真的按字典序**，顺序不对即报错。

`weighted_total` 字段刻意固定为 `null` —— schema 层面就阻断单一分数。

## 8. 商业价值口径

```
point_estimate   : 五项输入齐备 → 可给点值，但必须给公式与输入引用
scenario_range   : 缺一项或多项 → 保守/中性/乐观区间 + 缺失输入清单
not_estimable    : 缺 AI referral 或收入/线索价值 → 只给原因与数据清单
```

**不得**把 citation 变化直接换算为收入；**不得**用外部行业均值代替本项目数据。

## 9. 长期监测

固定 Prompt Universe 版本，六个切片维度各自输出窗口序列：

`engine_id` · `surface_id` · `market` · `locale` · `intent` · `topic`

**禁止合并**：国内与海外引擎、consumer 与 API surface、不同 market/locale。
`aggregated_across_slices = true` 会被校验器直接拒绝。

## 10. 七步流程

1. 确认 upstream：来自 GEO-04 / GEO-05 的 deferred handoff，或显式的效果验证请求
2. 锁定作用域：`engine_id::surface_id::market::locale` + `universe_version`
3. 切分 baseline 与 post 窗口，逐维度做可比性判定
4. 重算两窗口的 canonical KPI + 增长指标，并取护栏指标
5. 按流程判 `change_classification`，记录 materiality 与 basis
6. 按设计定 `attribution_level` 与 `confidence`，写 `confounders`
7. 给 `business_impact` 与 `recommended_action`，写 `trace_writeback`

## 11. 交接边界

| 观察到的问题 | 交给 | 边界 |
|---|---|---|
| 观测缺口 / 失败观测 | `geo_03` | 不补数 |
| citation failure 归因 | `geo_04` | 只消费 |
| 实体与权威判定 | `geo_05` | 只消费 |
| 统计功效与显著性 | `19` | 只产出测量结论 |
| 跨项目预算排序 | `19` | 不排序 |
| 内容 / 来源 / 标记落地 | `04` / `18` / `11` | 只提干预，不实施 |
| 月度复盘 | `20` | 输出作为输入 |

## 12. 反模板化要求

同样输入必须得到同样结论；**改变 evidence / control / baseline 必须改变 change_classification、
confidence 或 business conclusion**。由 `geo06_counterfactual_*` 用例检出。

## 13. 与 GEO-04 / GEO-05 的分工

| 问题 | 归属 |
|---|---|
| 为什么没被引用 | GEO-04 |
| AI 能否识别实体 / 竞品是否更权威 | GEO-05 |
| **优化后有没有效果** | **GEO-06** |
| **这个效果能不能归因到干预** | **GEO-06** |
| **值不值得继续投入** | **GEO-06** |

GEO-06 是 GEO-04 / GEO-05 的下游：它**消费**诊断与干预建议，**不重判** failure mode，
**不重算**可见性，**不重定义** KPI 口径。
