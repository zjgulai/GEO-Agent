# GEO 能力模型（GEO Capability Model）

**版本**：GEO 扩展层（GEO Extension）
**定位**：GEO 是 SEO Skill V1.5 之上的**扩展层**，不是第二套独立系统。本文件只说明能力分层与认识论边界，不定义业务规则；规则 Single Source of Truth 见 `GEO_MODULE_CONTRACT.yaml`、`GEO_SIGNAL_REGISTRY.yaml`、`GEO_METRIC_CONTRACT.yaml`。

---

## 1. 为什么采用扩展层

现有 SEO Core 01–20 已经拥有：抓取/索引资格（08）、渲染可发现性（09）、Schema（11）、内部链接（14）、内容架构（04）、影响力与数字公关（18）、实验与预测（19）、月度复盘（20）。

GEO 新增的真实空白只有三处：

1. **AI/生成式检索代理的可访问性**是独立于通用 crawler 的访问面（robots 中的 AI user-agent、WAF/CDN 对 AI 代理的处置、AI 抓取配额与来源许可），08 的规则覆盖搜索引擎 crawler，但不覆盖这个访问面。
2. **Prompt Universe** 是一种全新的 measurement instrument，SEO Core 中没有任何对象等价于“可冻结、可版本化、可复用的 prompt 集合”。
3. **Observed Citation** 要求把“原始模型响应”当作一等证据对象保存，并要求所有统计可回溯到 raw observation；SEO Core 的证据对象（SC02）没有 raw-generative-response 这一来源类型。

因此 GEO 只新增“AI 访问面判断”“prompt 测量工具”“生成式可见性观测层”三类机制，其余全部复用 SEO Core。

## 2. 三层认识论边界（核心原则）

必须严格区分三个**不同**的东西，它们的证据来源、判定 Owner 和可主张结论都不同：

| 层 | 名称 | 回答的问题 | 证据来源 | 判定 Owner | 可以主张 | 不可主张 |
|---|---|---|---|---|---|---|
| L1 | **Discoverability（可发现性）** | AI/搜索代理能否访问并取得这份内容？ | robots.txt、HTTP 状态、WAF/CDN 响应、渲染前后 HTML、indexability 控制、canonical | `geo_01`（AI 访问面）；最终 indexability/canonical 仍归 `08` | “该 URL 对某 AI user-agent 被阻断/可访问” | 不能主张“因此会被引用” |
| L2 | **Citation Readiness（引用就绪度）** | 站点是否具备被生成式答案引用的结构性条件？ | llms.txt / Schema / 事实密度 / 实体一致性 / 可摘录性 | **无独立 GEO 模块**：分别归 `11`（Schema）、`04`（内容架构）、`08`（可访问性） | 结构条件的现状描述 | 不能主张“具备条件就一定会被引用” |
| L3 | **Observed Citation（实测引用）** | 在某引擎/模型、某时刻、某 prompt 下实际发生了什么？ | 原始模型响应（raw response） | `geo_03` | 观测到的 brand mention / citation / 缺失 | 不能把一次观测外推为普遍规律 |

**三者互不蕴含。** `Discoverability ≠ Citation Readiness ≠ Observed Citation`。
L1 为 blocked **不**证明 L3 一定是 absent；L1 为 eligible **不**证明 L3 会出现 citation。
L2 的改进项 **不得**被表述为“实施后一定提高 AI citation”，除非有 L3 的前后对照观测。

## 3. 证据分级（沿用 SEO Core 语义）

### 3.1 爬虫与控制分类（Crawler / Control Taxonomy，L1 的前置分类）

L1 的判定必须先回答"被判定的是什么东西"。`geo/GEO_CRAWLER_TAXONOMY.yaml` 是这一分类的 Single Source of Truth，它强制区分三组容易混淆的对象：

| 区分 | 含义 | 典型例子 | 判定方式 |
|---|---|---|---|
| **robots product token ≠ HTTP user-agent** | 前者是 robots.txt 里的控制名，后者是真实请求身份 | `Google-Extended`（纯用途控制，无 HTTP 身份）vs `Googlebot`（真正抓取的 HTTP agent） | 用途控制只能记为 `geo.discovery.control_recorded`；不得对它做 HTTP 探测 |
| **training ≠ search_index** | 是否允许进入训练语料 vs 是否允许进入生成式检索索引 | `GPTBot`（training）vs `OAI-SearchBot`（search_index） | 两个控制面必须分别探测、分别判定；一个的状态不得推断另一个 |
| **autonomous crawler ≠ user_initiated fetch** | 自主调度抓取 vs 用户当场触发取回 | `GPTBot` vs `ChatGPT-User` | 用户触发取回的 robots 可控性按注册值处理，不得用 robots Disallow 判为阻断 |

分类词表：`class` = training / search_index / user_initiated / archival；`request_origin` = autonomous_crawler / user_triggered；`agent_kind` = http_agent / robots_only_token。

**推论（写进 guardrail）**：`Discoverability` 结论必须带 `control_ref` 与 `control_scope`，否则无法判断它到底在说"能不能训练抓取"还是"能不能出现在生成式答案里"。


GEO 全部结论沿用 `canonical_trace_schema.json` 的 Evidence `level` 枚举，不新增枚举：

- `direct`：直接抓取/实测所得（例如实测 fetch 到的 robots 行、实测 HTTP 状态、保存下来的 raw response）。
- `derived`：由 direct 证据按明确规则计算得出（例如按 observation 计算的 Brand Mention Rate）。
- `proxy`：间接指标（例如用第三方可见性工具的结果代替自测）。
- `inference`：未经验证的推断（例如“该 CDN 通常会拦截 AI 代理”）。
- `unknown`：无法获得证据。

**GEO 硬约束**：任何 `geo.*` signal 必须挂到至少一条 Evidence；`direct` 级别的 signal 不允许只由 `inference` 支撑。

## 4. 确定性优先

GEO 检查项必须是 **deterministic** 的：给定同一份输入（robots 文本、HTTP 响应、raw response、prompt universe 文件），判定结果必须可重复且逐字节一致。

- 不做"看起来像 AI 友好"的模糊打分。
- 每条判定都必须能指出触发它的具体输入片段（`trigger_snippet`，见 Signal Registry）。
- 无法确定性判定的内容一律落到 `unknown` 或 `evidence_gap`，而不是猜测。

### 4.1 AI 引擎注册表：引擎 → 交互面分层与"可观测性不对称"

`geo/GEO_ENGINE_REGISTRY.yaml` 是 GEO-02/GEO-03 选择观测对象的 SSOT。它把"引擎"当成需要显式建模的对象，而不是一份品牌名单，原因有两条。

**第一条：引擎不等于观测入口。** 同一引擎的**消费者产品**与**官方 API** 是不同链路 —— 不共享检索、排序、引用与个性化状态。因此 registry 采用两层结构：

- **engine**：厂商 + region + 引擎类型 + crawler 身份（robots 层的处置对象是引擎）
- **surface**：观测入口 + 观测通道 + 确定性 + 可用性 + 引用展示形态

观测地址写作 `<engine_id>::<surface_id>`（例如 `chatgpt::search_api`）。三条硬约束由此产生：

1. `no_api_equals_consumer` —— API surface 的结果不等于消费者产品答案
2. `no_cross_surface_merge` —— 同引擎不同 surface 不得合并成一个数字
3. `token_is_engine_level` —— robots token 属引擎层级，不得按 surface 分别声明

**第二条：国内与海外生态在四层维度上系统性不同**，不是同一套方法的两半：

| 不对称维度 | 表现 | registry 字段 |
|---|---|---|
| **可得性** | 部分引擎只在国内可访问，部分只在海外可访问 | `region` / `access` / `access_note_zh` |
| **观测通道** | 国内引擎普遍提供官方联网搜索 API；消费者产品通常无法在服务器环境稳定观测 | `surfaces[].observation_method` / `search_api` / `determinism` |
| **信源生态** | 国内答案的信源高度集中在少数平台，与海外分布明显不同 | `citation_display` |
| **crawler 透明度** | 国内厂商多数不公开 AI crawler 官方文档，robots 可干预性常常无法确认 | `crawler_identity` / `crawler_source_confidence` |

**观测通道词表**：`vendor_search_api`（确定性、产出原始响应）> `browser_automation`（半确定）> `manual_session`（人工）> `unavailable`（无通道，必须报证据缺口）。通道的确定性等级决定该结论可被主张的强度。

**UA 版本化策略**：crawler 身份分两部分 —— `robots.txt` 的 **product token** 是稳定标识（`GPTBot`、`Bytespider`、`Baiduspider`），UA 字符串里的**版本号与平台片段**不是（`GPTBot/1.3`、`Chrome/131.0.0.0`）。判定以 product token 为准；引用 UA 必须同时给出 `last_verified` 并说明版本可能已变化。

**复核时效**：`last_verified` 是人工对照厂商官方材料复核的日期，`stale_after_days` 默认 180 天；超期条目必须重新复核，否则其结论只能带 limitation 输出。

## 5. 不使用单一 GEO 总分（GEO Score）

**禁止**把 GEO 结果压缩成单一 0–100 分作为核心判断依据。

理由：
- 单一分数会把三层（L1/L2/L3）混在一起，掩盖“被阻断”“结构一般”“实测无引用”是完全不同的结论；
- 单一分数无法回溯到 raw observation，违反 evidence-first 要求；
- 权重无法验证，会制造“实施某项优化一定提升分数”的虚假因果。

允许存在的只有 `GEO_METRIC_CONTRACT.yaml` 中定义的 6 个 canonical KPI。每个 KPI 必须能回到 observation 集合，且必须与样本量、引擎/模型范围、执行时间窗一起报告。

## 6. 与 SEO Core 的关系

GEO **不**新建：crawl budget 审计、hreflang、CWV、Schema 设计、内部链接、外链审计、迁移、程序化 SEO、实验设计、月度复盘。
GEO **复用**这些能力：通过既有 Owner 的 Handoff 边界调用（见 `GEO_MODULE_MAP.md` 的 Dependency / Handoff Map）。

GEO 不修改 SEO 01–20 的任何业务规则，也不新增 SEO 侧的 signal 或 KPI。

## 7. 本期范围（Scope）

实现：`geo_01_ai_discoverability`、`geo_02_prompt_universe`、`geo_03_citation_visibility`、`geo_04_citation_diagnostics`、`geo_05_entity_authority`、`geo_06_measurement`。
明确不实现：GEO-07（建议见 `GEO_EXTENSION_ARCHITECTURE.md` 第 10 节），任何 dashboard / 数据库 / scheduler 产品层能力。

## 8. 本阶段明确不做的判定

- llms.txt、Schema、FAQ、结构化数据统一 **不**作为独立 GEO 模块（归属 11 / 04）。
- 不实现“生成式引擎排名”类判断（无可复现证据源）。
- 不实现跨引擎加权综合分。
- 不对未观测到的引擎/模型推断可见性。
