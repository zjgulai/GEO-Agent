# GEO-05 诊断方法（实体、权威与来源可信度诊断方法）

**定位**：GEO-01～03 回答"发生了什么"，GEO-04 回答"为什么没被引用"，GEO-05 回答
"AI 能不能认出我们、实体关系是否清楚、为什么竞品来源更权威、claim 有没有一手证据与独立印证"。
**机器可读 SSOT**：`GEO_05_ENTITY_AUTHORITY_TAXONOMY.yaml`（failure mode 与阈值）、
`GEO_05_DIAGNOSIS.yaml`（模块契约）、`geo/schemas/geo_entity_authority_schema.json`、
`geo/schemas/geo_entity_authority_diagnosis_schema.json`。
本文件只说明**怎么诊断**，不重复定义 failure mode 与阈值。

---

## 1. 认识论边界

GEO-05 输出**诊断假设**，不是因果结论。它不得声称"补齐某资产一定会带来引用"，也不得输出任何权威评分。

权威不是单点事实，而是**多维度证据状态**。因此：

- 单点优势（有 Schema、有 Wikipedia 页、有媒体报道、有大量外链）**不构成**权威结论
- 权威结论必须有**独立第三方**证据支撑，而非目标方自述
- 权威维度互相冲突时**保留冲突**，不平均、不消除

## 2. 什么情况可以下实体/权威诊断

一次合法的实体/权威诊断必须同时满足：

1. 底层 observation 的 `execution_status=ok`，且有 `raw_response_ref`
2. target 与至少一个竞争实体在同一 `engine_id::surface_id::market::locale` 下有 profile
3. 至少一个诊断维度 `comparable`（否则只能 `UNRESOLVED`）
4. 来自 GEO-04 时，作用域与父诊断完全一致

**不成立的情形**：

- 观测执行失败 → 那是观测缺口，交 `geo_03`，不是实体问题
- 只有目标方自述、连一手材料都没有 → 只能 `low` confidence，且必须证明已检索过一手与第三方来源
- 无法取得任一侧 profile → `UNRESOLVED`

## 3. 三层证据分离（优先动作）

对每条关键 claim，先做证据分类，再做维度判断。顺序不能颠倒。

```
claim
 ├── self_claim                      → 目标方自己说的
 ├── first_party_evidence            → 目标方产生、外部可核查的原始材料
 ├── independent_third_party_evidence → 无控制关系且不转述自述的独立来源
 └── none                            → 无出处
```

**独立印证的判定链**（必须逐条给出依据）：

| 检查 | 通过条件 | 不通过的后果 |
|---|---|---|
| 无控制关系 | `relation_to_target = none_observed` | 不计入印证，记入 `limitations` |
| 非转述 | `restates_first_party_statement = false` | 不计入，列入 `shared_origin_refs` |
| 来源类型 | 不是 `restatement` / `related_party` | 不计入 |
| 非同源 | 不与其他来源共引同一份自述 | 多个来源只算**一个**单元 |

**`independent_unit_count` 是实际计入的独立单元数，不是第三方来源的条数。**
两者不一致时，validator 会报错。

## 4. 十二维比较口径

| 维度 | 可比的判据 | 不可比的典型情形 |
|---|---|---|
| `entity_clarity` | 两侧实体指代明确度可并列比较 | 实体名与常见词同形且无消歧线索 |
| `alias_consistency` | 两侧别名集合都可取得 | 仅一个来源出现过该实体 |
| `relationship_clarity` | 两侧关系陈述可并列比较 | 无法确定产品归属哪个组织 |
| `author_institution_verifiability` | 两侧作者/机构信息都可取得 | 内容无具名作者且无机构归属 |
| `first_party_source_strength` | 两侧原始出处归属都可判定 | 无法判断谁是原始出处 |
| `original_research_assets` | 两侧原创资产都可清点 | 未观察到任何原创材料 |
| `claim_verifiability` | 两侧 claim 都能抽取并判定 | claim 无法从观测中抽取 |
| `third_party_corroboration` | 两侧都有第三方来源出现 | 观测窗口内没有第三方来源 |
| `external_source_quality` | 两侧外部来源都可分类 | 外部来源未在观测中出现 |
| `topic_coverage_depth` | 两侧覆盖深度可比较 | 目标方在该主题下无内容 |
| `source_independence` | 两侧来源关系可判定 | 无法判断来源间关系 |
| `freshness_and_continuity` | 两侧至少一侧有日期信号 | 无法取得任何日期信号 |

**`favors` 只允许**：`own_target` / `cited_competitor` / `tie` / `unclear`。
不得把"我方看起来更好"写成结论而不给证据。

## 5. 定向要求（`requires_favors`）

每个 failure mode 声明它**靠哪个维度区分**。该维度必须 `comparable` 且方向与该 mode 一致：

| failure mode | 定向维度必须偏向 |
|---|---|
| `ENTITY_AMBIGUOUS` | `entity_clarity` → `cited_competitor` |
| `ENTITY_ALIAS_CONFLICT` | `alias_consistency` → `cited_competitor` |
| `RELATIONSHIP_CONFLICT` | `relationship_clarity` → `cited_competitor` |
| `AUTHOR_IDENTITY_UNVERIFIABLE` | `author_institution_verifiability` → `cited_competitor` |
| `SELF_CLAIM_ONLY` | `third_party_corroboration` → `cited_competitor` |
| `FIRST_PARTY_EVIDENCE_WEAK` | `first_party_source_strength` → `cited_competitor` |
| `ORIGINAL_RESEARCH_WITHOUT_CORROBORATION` | `third_party_corroboration` → `cited_competitor` |
| `CORROBORATION_NOT_INDEPENDENT` | `source_independence` → `cited_competitor` |
| `COMPETITOR_FIRST_PARTY_STRONGER` | `original_research_assets` → `cited_competitor` |
| `COVERAGE_BREADTH_WITHOUT_DEPTH` | `claim_verifiability` → `cited_competitor` |
| `SOURCE_INDEPENDENCE_GAP` | `source_independence` → `cited_competitor` |
| `FRESHNESS_DECAY` | `freshness_and_continuity` → `cited_competitor` |
| `AUTHORITY_SIGNAL_CONFLICT` | 无定向要求（冲突本身即结论，须列两侧证据） |

## 6. 置信度派生（只由证据状态导出）

| confidence | 条件 |
|---|---|
| `high` | 必需维度全 `comparable`、两侧 profile 齐备、observation 有 `raw_response_ref`、已检索 counterevidence |
| `medium` | 必需维度 `comparable` 但 counterevidence 检索不完整，或有非必需维度不可比 |
| `low` | 有可比维度但关键一侧 profile 不完整；**只有 `self_claim` 时上限**；缺 `raw_response_ref` 时上限 |
| `unresolved` | 无任一维度可比、缺任一侧 profile、缺 claim 记录或观测不可追溯 |

**confidence 不由 failure mode 导出。** 同一个 mode 在不同证据状态下必须给出不同 confidence。

## 7. 七步流程

1. 确认入口合法（GEO-04 failure mode 或显式实体/权威问题），校验作用域继承
2. 锁定 `engine_id::surface_id::market::locale`
3. 为 target 与每个竞争实体各建 Entity / Authority Evidence Object
4. 逐条 claim 分类到三类证据之一（一证据不得跨类）
5. 排除利益相关方与同源转述，算 `independent_unit_count`
6. 逐维度比较，按 `required_dimensions` + `requires_favors` 定 mode，检查 `cannot_be_primary_when`
7. 定 confidence、给 `recommended_next_owner`、写 `trace_writeback`

## 8. 交接边界（GEO-05 不重复实现已有能力）

| 观察到的问题 | 交给 | 边界 |
|---|---|---|
| 实体命名/别名/结构化数据设计 | `11` | Schema 只作一致性事实 |
| 消歧页面、作者页、机构页结构 | `04` | 只诊断，不做内容方案 |
| 独立第三方来源建设 | `18` | 不用 backlink 数量代表权威 |
| 竞品一手数据整体更强 | `03` | 竞争与内容差距归 03 |
| 时效衰退与更新 | `17` | 更新决策归 17 |
| 观测缺口 | `geo_03` | GEO-05 不补数 |
| citation failure 归因 | `geo_04` | 只消费 handoff |
| 测量设计与跨市场可比性 | `geo_06`（已实现） | 交 GEO-06；GEO-05 不做测量 |

## 9. 反模板化要求

同样输入必须得到同样结论；**改变证据必须改变结论或 confidence**。
若两次运行 evidence 不同而 diagnosis 完全不变，即为模板化输出，由 counterfactual 用例
（`geo05_counterfactual_evidence_change`）检出。

## 10. 与 GEO-04 的分工

GEO-04 做 **9 维 source comparison**（意图、答案、证据、时效、实体、可摘录、一手、第三方、主题），
目的是**解释 citation 缺口**。

GEO-05 做 **12 维 entity/authority comparison**，目的是**解释实体与权威本身**，
其中 `entity_clarity` / `first_party_source_strength` / `third_party_corroboration` / `topic_authority`
与 GEO-04 名称相近但**口径不同**：

- GEO-04 的 `topic_authority` 是"相对深度观察"，**禁止**输出权威评价
- GEO-05 的 `topic_coverage_depth` 可以给出"覆盖广但证据弱"的判定，但**仍然禁止**任何权威评分
- GEO-04 的 `entity_clarity` 只比较命名一致性与指代明确度
- GEO-05 的 `entity_clarity` 在此基础上增加**别名归并**与**关系一致性**两层判断

两者不得互相替代；GEO-05 不重判 GEO-04 的 failure mode。
