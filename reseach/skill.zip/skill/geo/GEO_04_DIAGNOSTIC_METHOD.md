# GEO-04 诊断方法（引用失败诊断方法）

**定位**：GEO-01～03 回答"发生了什么"，GEO-04 回答"为什么目标品牌/页面没有被引用，而竞争来源被引用"。
**机器可读 SSOT**：`GEO_04_CITATION_FAILURE_TAXONOMY.yaml`（failure mode 与阈值）、`GEO_04_DIAGNOSIS.yaml`（模块契约）、`geo/schemas/geo_diagnosis_schema.json`、`geo/schemas/geo_source_profile_schema.json`。
本文件只说明**怎么诊断**，不重复定义 failure mode 与阈值。

---

## 1. 认识论边界（先说清楚 GEO-04 不做的事）

GEO-04 输出的是**诊断假设**，不是因果证明。

- 不得把 Schema / FAQ / llms.txt / 内容长度 / 关键词密度直接当作 citation 因果证据。
- 不得由 API surface 的观测推断 consumer surface 的行为，反之亦然。
- 不得用单个 prompt 的观测外推到意图、主题或引擎整体。
- 没有 counterevidence 检索时不得给 `high` confidence。
- 不得把"目标未被引用"直接等同于"目标内容质量差"。

**证据不足时的正确输出是 `low confidence` 或 `UNRESOLVED`，不是强行分类。**

## 2. 引用失败（Citation failure）的成立条件

一次 citation failure 成立的充要条件（定义见 taxonomy 的 `citation_failure_definition`）：

1. GEO-03 observation 的 `execution_status = ok`；
2. 该观测中自有侧缺失（brand mention 缺失 且/或 own-domain citation 缺失）；
3. 至少一个竞争来源出现（竞品 mention 或竞品 citation）。

三个条件任一不满足，就不是 citation failure：

- 自有侧已出现 → 不是缺口，可能是"提及但未被引用"，属于另一类现象；
- 观测执行失败 → 是**观测缺口**，不是引用缺口，回到 GEO-03；
- 只有自有侧缺失、没有任何竞争来源 → **不得**给出 `COMPETITOR_*` 类 failure mode。

## 3. 九维来源比较（Source comparison，优先动作）

诊断的**优先动作**是 target vs cited competitor 的成对来源比较。九个维度定义在 taxonomy 的
`diagnostic_dimensions.dimensions`，此处只说明操作方式：

| 维度 | 怎么比 | 常见不可比原因 |
|---|---|---|
| intent_alignment | 页面职责与题型是否对应 prompt 意图 | 页面不可访问 |
| answer_completeness | 逐要素列目标缺失项与竞争覆盖项 | 目标页面无可用正文 |
| evidence_provenance | 一手数据/方法/可追溯来源数量 | 两侧都未标注出处 |
| freshness | published / updated 日期或等效时效信号 | 无法取得任一日期 |
| entity_clarity | 实体命名一致性与同名冲突 | 实体名与常用词同形 |
| extractability | 段落自足性、结构信号、渲染依赖 | 正文依赖 JS 渲染 |
| primary_source_strength | 原始出处 / 二手汇编 / 转述 | 无法判断谁是原始出处 |
| third_party_corroboration | 观测中实际出现的独立第三方来源数 | 窗口内没有第三方来源 |
| topic_authority | 双方在该主题下的相对深度观察 | 目标方在该主题下无页面 |

**每个维度在一次诊断中必须出现且只能出现一次**，状态只能是 `comparable` 或 `not_comparable`（并给原因）。

### 3.1 两条维度专属边界

- `third_party_corroboration` 只统计**观测中实际出现的来源**。不得用外部工具推导"应该有多少第三方来源"。
- `topic_authority` 只能给**相对观察**。禁止输出域名权威度评分或任何外部权威指标。

### 3.2 维度证据表（`geo_source_profiles.json`）

维度比较必须落到结构化的 source profile 上，而不是纯文字判断。每个 profile 描述**一个来源在某个
`<engine_id>::<surface_id>` 下的实际观察**，字段见 `geo_source_profile_schema.json`：

- `source_role`: `own_target` / `cited_competitor` / `third_party_corroborator`
- `page`、`intent_declared`、`page_role`、`answer_elements[]`、`provenance_marks[]`
- `published_at` / `updated_at` / `observed_date_signals[]`
- `entity_name_in_page`、`entity_name_conflicts[]`、`disambiguation_present`
- `self_contained_segments[]`、`structural_signals[]`、`render_dependency`
- `primary_source_relation`、`topic_depth_signals[]`
- `observed_at`、`evidence_id`

**`render_dependency: client_side_only` 时不得判定 `EXTRACTABILITY_WEAK`** —— 此时应先走
`09`（rendering）handoff，而不是把渲染问题当成内容可摘录性问题。

## 4. 诊断流程（7 步）

1. **锁定观测**：选定 `observation_id`，校验 citation failure 成立条件；取该观测的
   `prompt_id` / `engine_id` / `surface_id`。
2. **保持 surface 隔离**：本次诊断只能引用**同一** `engine_id::surface_id` 的观测与 profile。
   **不同 surface 的结论冲突时，不得跨 surface 推因果** —— 输出 surface 级分别结论 + 冲突记录。
3. **构建来源画像**：为目标与每个被引用的竞争来源建立 source profile（第 3.2 节）。
4. **逐维度比较**：填满 9 个维度，标注 `comparable` / `not_comparable` 与原因。
5. **映射 failure mode**：按 taxonomy 的 `required_dimensions` 与 `cannot_be_primary_when` 判定；
   可并存多个，指定 `primary_failure_mode`，其余进 `secondary_failure_modes`。
6. **定 confidence**：严格按 taxonomy 的 `confidence_policy` 由证据状态导出，不得由 failure mode 类型导出。
7. **给 handoff 与补证清单**：`recommended_next_owner` 必须取自 taxonomy 的 `handoff_map`；
   `counterevidence_refs` 与 `unresolved_gaps[]` 必须具体到可执行动作。

## 5. 交接边界（Handoff：GEO-04 不重复实现已有能力）

| Root cause | Owner | 说明 |
|---|---|---|
| crawl/index、robots、canonical、AI 代理可访问性 | `geo_01`（技术修复顺序归 `08`/`09`） | 可访问性结论由 GEO-01 给 |
| 内容结构、答案要素、可摘录形态 | `04` | GEO-04 不产内容方案 |
| 查询与页面职责冲突 | `15` | 意图错配可能表现为页面职责冲突 |
| 内容衰退与更新 | `17` | 时效落后交 17 |
| 第三方印证与站外资产 | `18` | 第三方来源建设交 18 |
| 渲染可摘录性 | `09` | 依赖 JS 渲染时交 09 |
| 结构化数据一致性 | `11` | Schema 只作一致性事实，不作因果证据 |
| 实体与权威深层分析 | `geo_05`（已实现） | GEO-04 只给相对观察，判定归 GEO-05 |
| 观测不足 / 需重跑扩窗 | `geo_06`（已实现） | 交 GEO-06 做测量设计与窗口可比性；证据清单随 handoff 传出 |
| 观测本身失败或不可追溯 | `geo_03` | 观测缺口回到 GEO-03 |

## 6. 反模板化要求

同样输入必须得到同样结论；**改变证据必须改变结论或 confidence**。
这一条由 counterfactual 回归用例强制：至少准备两个反事实变体，修改 evidence 后 diagnosis 或
confidence 必须发生变化，否则视为模板化输出。

## 7. 与 GEO-03 的分工

| 问题 | Owner |
|---|---|
| 观测到了什么（提及/引用/缺失/失败） | `geo_03` |
| 为什么缺失，竞争来源哪些维度占优 | `geo_04` |
| 可见性数字与时间序列比对 | `geo_03`（KPI）/ `geo_06`（未来） |
| 实体与权威的体系化分析 | `geo_05`（未来） |
