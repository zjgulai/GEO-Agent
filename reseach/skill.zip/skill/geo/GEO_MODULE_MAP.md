# GEO 模块地图（GEO Module Map：模块边界与依赖 / 交接关系）

**版本**：GEO 扩展层 | **机器可读来源**：`GEO_MODULE_CONTRACT.yaml`（模块契约）、`GEO_SIGNAL_REGISTRY.yaml`（signal）、`GEO_METRIC_CONTRACT.yaml`（KPI）、`../router.yaml`（路由与升级）、`../ownership_registry.yaml`（Owner 权威）。
本文件只提供人类可读的地图；任何规则冲突以机器可读文件为准。

---

## 1. 模块总览

| Module ID | 别名 | Layer | Capability domain | Owner | 一句话职责 |
|---|---|---|---|---|---|
| `geo_01` | GEO-01 | L1 Discoverability | `geo_discoverability` | `geo_01` | 实测 AI/搜索代理能否访问这些 URL |
| `geo_02` | GEO-02 | L2 Citation Readiness | `geo_prompt_universe` | `geo_02` | 建设可冻结、可版本化的 prompt universe 测量工具 |
| `geo_03` | GEO-03 | L3 Observed Citation | `geo_citation_visibility` | `geo_03` | 逐 prompt 观测并保存可追溯的引用与提及证据 |
| `geo_04` | GEO-04 | L4 Diagnosis | `geo_citation_diagnostics` | `geo_04` | 解释"为什么目标未被引用而竞争来源被引用"，输出可追溯诊断 |
| `geo_05` | GEO-05 | L4 Diagnosis | `geo_entity_authority` | `geo_05` | 解释 AI 能否稳定识别实体、实体关系是否清楚、为什么竞品来源更权威、claim 是否有独立印证 |
| `geo_06` | GEO-06 | L4 Diagnosis | `geo_measurement` | `geo_06` | 验证优化后是否真的有效、能否归因、是否值得继续投入；基线/复测、变化判断、实验契约与商业价值 |

GEO-01～06 已全部实现并通过验证；没有任何预留 domain 处于未实现状态（见 `GEO_EXTENSION_ARCHITECTURE.md`）。

## 2. 信号地图（Signal Map，定义见 `GEO_SIGNAL_REGISTRY.yaml`）

| Signal ID | Layer | 发出方 | 触发要点 |
|---|---|---|---|
| `geo.discovery.block` | L1 | `geo_01` | robots Disallow / 代理被拒状态 / 仅客户端渲染，且有命中片段 |
| `geo.discovery.eligible` | L1 | `geo_01` | 必需 probe 全部 direct 且无阻断 |
| `geo.discovery.control_recorded` | L1 | `geo_01` | robots-only 用途控制 token（例如 Google-Extended）：只记录控制事实，无 HTTP 身份 |
| `geo.discovery.evidence_gap` | L1 | `geo_01` | 必需 probe 未取得证据（是"未知"，不是"阻断"） |
| `geo.prompt.coverage_gap` | L2 | `geo_02` | 声明维度格子为空，或 prompt 从未获得有效观测 |
| `geo.prompt.metadata_drift` | L2 | `geo_02` | 同一版本内 metadata_hash 不一致 / id 复用 / 冻结后原地修改 |
| `geo.brand.mention` | L3 | `geo_03` | raw response 命中自有实体归一化别名 |
| `geo.brand.absent` | L3 | `geo_03` | ok 观测中无任何自有别名命中 |
| `geo.citation.own_domain` | L3 | `geo_03` | 出现自有域名 citation URL |
| `geo.citation.competitor` | L3 | `geo_03` | 出现竞品域名 citation 或竞品别名提及 |
| `geo.citation.gap` | L3 | `geo_03` | 竞品侧有证据而自有侧无证据 |
| `geo.observation.error` | L3 | `geo_03` | 执行失败 / 缺 raw response，且不得计入任何 KPI |
| `geo.diagnosis.failure_mode` | L4 | `geo_04` | 基于 9 维比较给出可追溯的 citation failure mode |
| `geo.diagnosis.unresolved` | L4 | `geo_04` | 证据不足以归因；必须列出补齐清单，不得猜测 |
| `geo.diagnosis.surface_conflict` | L4 | `geo_04` | 同引擎不同 surface 结论冲突；只记录，不跨 surface 推因果 |
| `geo.entity.identified` | L4 | `geo_05` | 实体在本次观测内可被稳定识别 |
| `geo.entity.ambiguous` | L4 | `geo_05` | 实体无法稳定识别或被同名稀释 |
| `geo.entity.alias_conflict` | L4 | `geo_05` | 别名写法互相竞争且无法归并 |
| `geo.entity.relationship_conflict` | L4 | `geo_05` | 品牌—产品—组织关系互斥或缺失 |
| `geo.authority.claim_evidence` | L4 | `geo_05` | 关键 claim 的三类证据分工与可验证性 |
| `geo.authority.independence_gap` | L4 | `geo_05` | 支持来源不独立（利益关系 / 同源转述） |
| `geo.authority.signal_conflict` | L4 | `geo_05` | 权威维度方向相反，保留冲突不平均 |
| `geo.authority.unresolved` | L4 | `geo_05` | 实体/权威证据不足，列出补齐清单 |
| `geo.measurement.change_classified` | L4 | `geo_06` | 两可比窗口之间的变化分类与依据 |
| `geo.measurement.inconclusive` | L4 | `geo_06` | 不可比或样本不足，无法判断变化 |
| `geo.measurement.incomparable_windows` | L4 | `geo_06` | 两窗口在 universe/surface/market 等维度不可比 |
| `geo.measurement.guardrail_triggered` | L4 | `geo_06` | 护栏指标恶化，不得判成功 |
| `geo.measurement.experiment_designed` | L4 | `geo_06` | 干预实验九项契约已建立 |
| `geo.measurement.business_range_only` | L4 | `geo_06` | 商业价值输入不足，只能给区间 |
| `geo.measurement.longitudinal_slice` | L4 | `geo_06` | 按 engine/surface/market/locale/intent/topic 的切片序列 |

## 3. 模块间依赖（GEO 内部）

```
                     geo_02  (frozen prompt universe + entity alias table)
                        │  universe_version / prompt_id / metadata_hash / alias table
                        ▼
   geo_01 ──────────► geo_03  (execute prompts, store raw response, extract, compute KPI)
   (AI agent access      ▲            ▲                    │
    surface facts)       │            │ engine_id /        │ observations + raw response
                         │            │ surface_id         ▼
                         │            │ 来自 ENGINE       geo_04  (9 维 target vs competitor 比较
                         │            │ REGISTRY           │        → failure mode + confidence)
                         │ own_domains / competitor_domains  │
                         │ 来自 universe                     ▼
                         │                          诊断假设 → handoff 回已有专业域
                         │
   geo_01 与 geo_03 的结论分别报告，不合并为单一分数或单一结论
```

- `geo_03` 是 `geo_02` 与 `GEO_ENGINE_REGISTRY.yaml` 的**纯消费方**：运行期不得改写 prompt、维度、别名表，也不得自造引擎。
- `geo_04` 是 `geo_03` 的**纯消费方**：只消费 observation 与 raw response，不重算可见性、不补数；缺证据时输出 `UNRESOLVED`。
- `geo_01` 与 `geo_03` **无数据依赖**，只有解释边界约束：L1 状态不得用于推断 L3 结果。
- `geo_04` 与 `geo_01` 只在 `DISCOVERY_BLOCKED` 上有证据引用关系：诊断引用 GEO-01 的阻断结论，不自己判定可访问性。
- `geo_02` 的 `geo.prompt.coverage_gap` 可同时由 `geo_02`（建库阶段）与 `geo_03`（观测阶段缺失有效观测）触发；signal 的 Owner 始终是 `geo_02`（原子定义在 registry 中只有一条）。

## 4. 与 SEO Core 的依赖 / 交接地图（Dependency / Handoff Map）

GEO 不重建任何已存在的技术 SEO 能力；需要 SEO Core 的最终判断时，一律按 `ownership_registry.yaml` 的注册 Owner 交接。

| GEO 模块 | Handoff 目标 | Domain | 边界（谁做什么） |
|---|---|---|---|
| `geo_01` | `08` | `indexability` | GEO 只提供 AI 代理访问面的实测事实；最终 indexability / canonical / robots / Sitemap 结论归 08 |
| `geo_01` | `09` | `rendering` | 阻断源于客户端渲染时，HTML/DOM 差异与渲染结论归 09；geo_01 只记录探测代理实际取得的正文 |
| `geo_02` | `04` | `content_architecture` | GEO 只声明哪些维度格子没有 prompt；主题与集群含义归 04 |
| `geo_02` | `03` | `competitive_opportunity` | 缺口是否需要竞品或内容差距确认归 03 |
| `geo_03` | `03` | `competitive_opportunity` | 引用缺口对应的查询与竞品内容判断归 03 |
| `geo_03` | `04` | `content_architecture` | 缺口集中在特定主题集群时的内容结构判断归 04 |
| `geo_03` | `08` | `indexability` | 被引用自有 URL 的 indexability / canonical 现状判断归 08 |
| `geo_03` | `14` | `internal_linking` | 被引用 URL 的站内可达性判断归 14 |
| `geo_03` | `17` | `content_lifecycle` | 已存在页面的衰退判断归 17 |
| `geo_01` / `geo_02` / `geo_03` | `semantic_review` | —— | 仅供需要人工复核的 Handoff；Decision.owner 仍为 GEO 注册 Owner |

### 4.1 GEO-04 的交接边界（诊断归因）

GEO-04 只做**诊断假设**，root cause 属已有专业域时一律 handoff，不重复实现：

| Root cause | Owner | 说明 |
|---|---|---|
| crawl/index、robots、AI 代理可访问性 | `geo_01` | 可访问性结论由 GEO-01 给 |
| 索引资格与 canonical 技术处置 | `08` | 最终 indexability 结论归 08 |
| 依赖 JS 渲染导致不可摘录 | `09` | GEO-04 不判定渲染能力 |
| 答案要素、内容结构、可摘录形态 | `04` | GEO-04 不产出内容方案 |
| 意图与页面职责冲突 | `15` | 意图错配可能表现为页面职责冲突 |
| 时效落后与内容衰退 | `17` | 更新/合并/下线处置归 17 |
| 第三方印证与站外资产 | `18` | 证据建设归 18 |
| 结构化数据一致性 | `11` | **Schema 只作一致性事实，不得作为 citation 因果证据** |
| 竞争来源整体更优 | `03` | 竞争与内容差距判断归 03 |
| 实体与权威深层分析 | `geo_05`（已实现） | 只做诊断与交接；Schema 设计归 11、内容方案归 04、来源建设归 18 |
| 观测不足 / 需重跑扩窗 | `geo_06`（已实现） | 交 GEO-06 做测量设计与窗口可比性 |
| 观测本身失败或不可追溯 | `geo_03` | 观测缺口回到 GEO-03 |

Failure mode 与维度阈值定义见 `GEO_04_CITATION_FAILURE_TAXONOMY.yaml`；9 维比较口径与 7 步流程见 `GEO_04_DIAGNOSTIC_METHOD.md`。
**复用而不重建的 SEO Core 能力**

| 能力 | 归属 Owner | GEO 如何使用 |
|---|---|---|
| 抓取、索引资格、canonical、robots、Sitemap | `08` | 通过 Handoff 提交事实并接受 08 的最终结论；GEO 只补充“AI 代理”这一访问面 |
| JavaScript 渲染与 HTML/DOM 差异 | `09` | 通过 Handoff 提交渲染阻断事实 |
| Schema / 结构化数据 | `11` | 不新建 GEO Schema 模块；引用就绪度中的结构化条件仍由 11 判断 |
| 主题权威与内容集群 | `04` | 覆盖缺口的内容侧含义交 04 |
| 竞品与内容差距 | `03` | 引用缺口的竞争含义交 03 |
| 内部链接与孤岛 | `14` | 被引用 URL 的可达性交 14 |
| 内容生命周期与衰退 | `17` | 已存在页面的衰退判断交 17 |
| 外链与数字公关 | `18` | 竞品被引用来源涉及站外资产时交 18 |
| 实验设计、预测与因果边界 | `19` | GEO 的新增结论不得绕过 19 的因果与预测门槛 |
| 月度复盘与 KPI 呈现 | `20` | GEO KPI 以独立小节进入复盘，不替换 SEO KPI |
| 证据对象标准化 | `SC02`（shared） | observation 的 provenance 要求沿用 SC02，并新增 raw response 来源类型 |
| 统一验证契约 | `SC12`（shared） | 每个 GEO 修复候选都要给出上线前后证据与验收标准 |

**Traversal 顺序（GEO）**

```
geo_01 ─► geo_02 ─► geo_03
   │          │        │
   └──────────┴────────┴──► SEO Core Owner（08 / 09 / 03 / 04 / 14 / 17 / 18）
                          └─► 19 Portfolio/Experiment（需要跨项目排序或因果结论时）
```

`geo_02` 可以在没有观测的情况下独立运行（只交付 instrument）；`geo_03` 必须依赖已冻结的 `geo_02` 产出；`geo_01` 可独立运行，其结果不构成 `geo_03` 的前置条件。

## 5. 爬虫与控制分类速查（定义见 `GEO_CRAWLER_TAXONOMY.yaml`）

| controller | robots token | class | agent_kind | robots 可控 | 说明 |
|---|---|---|---|---|---|
| `gptbot` | GPTBot | training | http_agent | 是 | OpenAI 训练语料控制面 |
| `oai_searchbot` | OAI-SearchBot | search_index | http_agent | 是 | OpenAI 检索/答案控制面，独立于 GPTBot |
| `chatgpt_user` | ChatGPT-User | user_initiated | http_agent | 否 | 用户触发取回，robots 可能不适用 |
| `google_extended` | Google-Extended | training | **robots_only_token** | 是 | 只约束 Gemini 训练/grounding；不影响 Googlebot 抓取与索引；无 HTTP 身份 |
| `googlebot` | Googlebot | search_index | http_agent | 是 | 真正执行抓取的 HTTP agent |
| `claudebot` | ClaudeBot | training | http_agent | 是 | 训练语料 |
| `claude_searchbot` | Claude-SearchBot | search_index | http_agent | 是 | 检索质量 |
| `claude_user` | Claude-User | user_initiated | http_agent | 是 | 用户触发取回 |
| `perplexitybot` | PerplexityBot | search_index | http_agent | 是 | 官方声明不用于基础模型训练 |
| `perplexity_user` | Perplexity-User | user_initiated | http_agent | 否 | 官方说明一般忽略 robots |
| `ccbot` | CCBot | archival | http_agent | 是 | 开放语料归档，下游可能用于训练 |

默认探测集合（`default_agent_set`）：国内优先 `baiduspider`、`bytespider`、`doubaobot`、`qwenbot`、`tongyibot`、`kimibot`；海外优先 `gptbot`、`oai_searchbot`、`claudebot`、`perplexitybot`、`ccbot`。全体成员均为可实测的 HTTP agent，且同时覆盖 training 与 search_index 两个控制面。

## 6. AI 引擎注册表速查（定义见 `GEO_ENGINE_REGISTRY.yaml`）

**引擎 → 交互面分层**：引擎是厂商与其检索/答案链路；交互面（surface）是实际接触入口。观测地址写作 `<engine_id>::<surface_id>`。robots 的 product token 属**引擎层级**，不属于交互面。

| engine_id | 名称 | 区域 | 可观测表面（默认加粗） | crawler 身份 |
|---|---|---|---|---|
| `doubao_ai` | 豆包 | cn | consumer_app / **search_api**（火山方舟） | documented（第三方源） |
| `yuanbao_search` | 腾讯元宝 | cn | consumer_app / **search_api**（元宝搜索 SearchPro） | **undocumented** |
| `deepseek` | DeepSeek | cn | **consumer_app（manual 唯一通道）** / api（unavailable） | **undocumented** |
| `tongyi_ai` | 通义千问 | cn | consumer_app / **search_api**（百炼 DashScope） | vendor_reported |
| `wenxin_yiyan` | 文心一言 | cn | consumer_app / **search_api**（千帆百度 AI 搜索） | documented（Baiduspider 官方） |
| `kimi` | Kimi | cn | consumer_app / **search_api**（`/v1/tools/search`） | vendor_reported |
| `zhipu_qingyan` | 智谱清言 | cn | consumer_app / **search_api**（BigModel web_search） | undocumented |
| `quark_ai` | 夸克 AI 搜索 | cn | **consumer_app（manual）** | undocumented |
| `metaso_ai` | 秘塔 AI 搜索 | cn | **consumer_app（manual）** | undocumented |
| `tiangong_ai` | 天工 AI | cn | **consumer_app（manual）** | undocumented |
| `chatgpt` | ChatGPT | global | consumer_app / **search_api**（Responses web search） | official |
| `google_ai_overviews` | Google AI Overviews | global | **search_product（browser）** —— 无对应官方 API | official（含用途控制 token） |
| `google_gemini` | Gemini | global | consumer_app / **search_api**（Grounding with Google Search） | official |
| `claude` | Claude | global | consumer_app / **search_api**（server-side web search tool） | official |
| `grok` | Grok | global | consumer_app / **search_api**（Live Search） | **undocumented** |
| `copilot` | Microsoft Copilot | global | consumer_app / **search_api**（Bing Web Search） | undocumented（Bing crawler 未登记） |
| `perplexity` | Perplexity | global | consumer_app / **search_api**（Sonar） | official |

**三条分层硬规则**

1. `no_api_equals_consumer` —— API surface 的答案不得等同于消费者产品 surface 的答案。
2. `no_cross_surface_merge` —— 同一引擎的不同 surface 不得合并成一个数字。
3. `token_is_engine_level` —— 禁止为同一引擎的不同 surface 声明不同的 robots token。

**区域硬规则**：国内与海外引擎的可见性数字必须分列，禁止合并为单一结论（`no_aggregate_across_regions`）。

## 7. 明确不做的边界

- 不新增“llms.txt 模块”“Schema 模块”“FAQ 模块”。
- 不新增 crawl budget、hreflang、CWV、内部链接、外链、迁移、程序化 SEO 的 GEO 版本。
- 不把单一 0–100 GEO Score 作为核心判断；不输出跨引擎加权综合分。
- 不在无前后对照观测时声称“某项优化提升 AI citation”。
- 不实现 GEO-05～07、dashboard、数据库或 scheduler。
