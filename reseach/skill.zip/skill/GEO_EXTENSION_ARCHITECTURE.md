# GEO 扩展架构（GEO Extension Architecture）

**状态**：GEO-01～06 已全部实现并通过验证（GEO-07 及以后未实现） | **基线**：SEO Skill V1.5（canonical profile `canonical_v1_5`），SEO Core 01–20 未修改业务规则
**权威文件**：`geo/GEO_MODULE_CONTRACT.yaml`、`geo/GEO_SIGNAL_REGISTRY.yaml`、`geo/GEO_METRIC_CONTRACT.yaml`、`geo/GEO_MODULE_MAP.md`、`geo/GEO_CAPABILITY_MODEL.md`、`geo/GEO_CRAWLER_TAXONOMY.yaml`、`geo/GEO_ENGINE_REGISTRY.yaml`、`geo/GEO_04_CITATION_FAILURE_TAXONOMY.yaml`

---

## 1. 为什么采用扩展层，而不是重写 SEO Skill

### 1.1 架构审计结论（编码前完成）

审计范围：仓库根 `skill/` 下的全部控制文件、20 个模块、8 个 domain services、canonical schema/contract、2 个静态验证器、1 个 canonical trace 验证器、测试 fixtures。

| 现有机制 | 位置 | GEO 的处理 |
|---|---|---|
| 两阶段路由（stage_1 primary / stage_2 owner escalation） | `router.yaml` | **复用**：新增 3 个 GEO route + 1 个 `geo_signals` 升级组，SEO 部分不动 |
| Owner 权威表 | `ownership_registry.yaml` | **复用**：新增 3 个 `geo_*` capability domain，SEO 20 个 domain 不动 |
| 模块身份注册表 | `module_identity_registry.yaml` | **复用**：新增 3 个 module id，`source_sentinels` 与 `review_sink` 不动 |
| canonical trace contract（profile / gate_order / status 优先级） | `canonical_trace_contract.yaml` | **不改**：GEO 复用既有 contract，未发现无法表达的字段 |
| canonical trace schema（Plan / Evidence / Decision / Handoff / Result） | `canonical_trace_schema.json` | **不改**：GEO 结论用既有 `claim` / `owner` / `dependency` Decision 与 Handoff 表达 |
| 最小执行协议（Plan → Reason → Validate） | `minimal_execution_protocol.yaml` | **不改**：GEO 模块遵循同一协议 |
| runtime invariants（SEM01–SEM10） | `runtime_invariants.yaml` | **不改**：GEO 结论继承 SEM04 evidence calibration 与 SEM10 provenance preservation |
| 静态架构验证器 | `validators/validate_v1_4_architecture.py` | **复用**：仍只检查 20 个 SEO 模块（正则限定 `0X/1X/20` 前缀），GEO 文件不干扰 |
| canonical trace 验证器 + 确定性规则 | `scripts/validate_v1_5_architecture.py`、`scripts/canonical_validator.py` | **复用**：GEO trace 与混合 SEO+GEO trace 直接用它验证 |
| 证据对象标准化（provenance / 时间 / 范围 / 可复核位置） | `domain_services/SC02` | **复用**：observation 沿用，并新增 raw response 作为来源类型 |
| 统一验证契约 | `domain_services/SC12` | **复用**：每个 GEO 修复候选都要给验收标准 |
| 索引资格判断 | `domain_services/SC05` | **复用**：最终 indexability 仍由 08 出结论 |
| 计划验证器 / trace schema | `state_schema.json`、`trace_schema.json`、`validators/validate_minimal_trace.py` | **不改** |

审计同时确认了三处**真实空白**，也是 GEO 唯一新增的三类机制：

1. **AI/搜索代理访问面**：08 覆盖搜索引擎 crawler，但不覆盖 AI user-agent 的 robots 规则、WAF/CDN 对 AI 代理的拒绝、以及“内容仅客户端渲染导致代理取不到正文”这一独立判定维度。
2. **Prompt Universe 作为测量工具**：SEO Core 中不存在“可冻结、可版本化、可复用的 prompt 集合”这一对象；关键词研究（02/03/04）在目的、粒度与稳定性要求上都不同。
3. **原始生成式响应作为一等证据**：SC02 的证据来源覆盖网页/GSC/抓取/SERP/日志，不包含 raw generative response，也没有“统计必须逐条回溯到原始响应”的强制要求。

### 1.2 不重写的理由

- SEO Core 01–20 已固化为 `references/rule_fidelity_manifest.yaml` 的 85 条原子规则并有 holdout 证据；重写会破坏这套保真证据链。
- 路由、Owner、Signal、Decision、Handoff、canonical trace、runtime invariant、validation 已经构成完整可验证骨架；GEO 需要的表达能力它都已具备。
- GEO 的真实增量只有上述三类机制，独立成系统会立刻产生第二套 router / ownership / evidence 定义，直接违反 Single Source of Truth。
- 因此 GEO 以 **extension layer** 落地：新增命名空间（`geo_*` module、`geo.*` signal、`geo_*` capability domain），复用全部既有机制。

### 1.3 开源项目机制参考（仅参考机制设计，未复制任何代码）

- **Auriti GEO Optimizer**（[repo](https://github.com/Auriti-Labs/geo-optimizer-skill)）：确定性 audit 路径（HTTP 抓取 + 规则判定，不用 LLM 打分）、versioned JSON contract（`schema_version` + frozen fixture）、以 `skill.yaml` 声明 `when_to_use / required_inputs / expected_outputs / guardrails`，并明确声明“只测 readiness，不保证被引用”。
  → 本阶段采纳：**skill/module contract 化**、**确定性判定**、**显式 guardrail**。本阶段**未采纳**其 0–100 分与 band 机制（与“不使用单一 GEO Score”原则冲突）。
- **CiteGEO**（[repo](https://github.com/ankit373/citegeo)）：人工 approve 的 prompt set（未批准不运行）、每条 attempt 保存 raw provider response + record hash、把 provider citation / search result / answer 正文 URL 三类来源分开、明确 `null`（无法计算）与 `0%`（真实未出现）严格区分。
  → 本阶段采纳：**approved/frozen prompt set**、**raw response + sha256 可追溯**、**失败与 absent 分离**。
- **Gego**（[repo](https://github.com/AI2HU/gego)）：canonical brand + alias 表（唯一索引 + 内存缓存 + `ResolveBrand`）、`llm.Provider` 统一接口（`Name/Generate/Validate/ListModels`）、run history 与 per-job retry。
  → 本阶段采纳：**universe 级 alias 归一化表**、**provider/model 抽象字段**、**run/observation 台账与失败分类**。本阶段**未采纳**其 Postgres/Mongo/etcd 运行时（属产品层，明确禁止）。
- **GEO-Bench**（[arXiv:2311.09735](https://arxiv.org/abs/2311.09735)、[repo](https://github.com/GEO-optim/GEO)）：10K query 经多 source dataset 汇集并按 domain / query type / intent 等维度打 tag，固定 seed 与完整 test split 评测。
  → 本阶段采纳：**维度化 categorization**（Topic / Persona / Journey Stage / Intent / Archetype）与**冻结集合 + 固定版本**的 benchmark 思路。本阶段**未采纳**其 Subjective Impression 类主观指标（不可复现）。

跨项目共性（4/4 出现）也直接写进了本阶段的硬约束：冻结的 prompt set、逐 observation 保存 raw response、provider/model 抽象、alias 归一化、版本化 contract、以及 “absence ≠ zero”。

---

## 2. GEO-01～06 与现有 SEO 模块的边界

| 判定问题 | Owner | 说明 |
|---|---|---|
| 该 URL 对某 AI user-agent 是否可访问 | `geo_01` | 新增能力：AI 访问面（robots 中的 AI UA、WAF/CDN 对代理的处置、代理能否取得非 JS 正文） |
| 该 URL 对搜索引擎 crawler 的 indexability / canonical / robots / Sitemap | `08` | 不变。`geo_01` 只提交实测事实 |
| HTML/DOM 渲染差异与客户端路由可发现性 | `09` | 不变。渲染阻断原因交 09 |
| Schema / 结构化数据 / Rich Results | `11` | 不变。**不新建 GEO Schema 模块** |
| 页面性能 CWV | `10` | 不变 |
| 内部链接与孤岛 | `14` | 不变 |
| 关键词研究与搜索量 | `02`/`03`/`04` | 不变。`geo_02` 不做关键词研究 |
| 主题权威与内容集群 | `04` | 不变。`geo_02` 只声明维度覆盖缺口 |
| 竞品与内容差距 | `03` | 不变 |
| prompt universe 的建立、冻结与版本化 | `geo_02` | 新增能力：measurement instrument |
| 某引擎/模型在某 prompt 下的实际响应、提及、引用 | `geo_03` | 新增能力：observation layer + raw response 留档 |
| 跨引擎可见性结论、因果与预测 | `19` | 不变。GEO 观测不得绕过 19 的因果门槛 |
| 月度 KPI 呈现 | `20` | 不变。GEO KPI 以独立小节进入 |
| 外链与数字公关机会 | `18` | 不变 |

**硬边界**：`Discoverability ≠ Citation Readiness ≠ Observed Citation`。三层结论必须分别报告，任何一层都不得用于推断另一层。

---

## 3. 复用 SEO Core 的能力
见 `GEO_MODULE_MAP.md` 第 4 节的复用表与 Dependency/Handoff Map。要点：

- **执行骨架全复用**：Plan / Evidence / Decision / Handoff / Result、canonical trace contract 与 schema、runtime invariants、availability 与 dependency 机制、deterministic validator。
- **验证机制全复用**：GEO trace 与混合 SEO+GEO trace 直接用 `scripts/validate_v1_5_architecture.py` 验证，未新建第二套 trace 语义。
- **服务复用**：SC02（证据 provenance）、SC05（索引资格口径）、SC12（验证契约）。
- **权威单一**：Owner 只写在 `ownership_registry.yaml`；signal 升级只写在 `router.yaml` 的 stage_2；signal 原子定义只写在 `GEO_SIGNAL_REGISTRY.yaml`；KPI 只写在 `GEO_METRIC_CONTRACT.yaml`。模块 Markdown 只写作业指导，不复制以上任何一条规则。

## 4. 新增的 GEO 专属机制（GEO-specific mechanism）

1. **AI 访问面探测矩阵（`geo_01`）**：先按 `GEO_CRAWLER_TAXONOMY.yaml` 对"被判定对象"分类，再产出 per-URL / per-agent / per-control-scope 的离散状态（`eligible` / `eligible_with_conditions` / `blocked_full` / `blocked_partial` / `evidence_gap` / `control_recorded`），7 类 probe（`robots_fetch` / `robots_rule_eval` / `http_status` / `waf_probe` / `render_snapshot` / `indexability_control` / `canonical_check`），block 判定必须携带命中片段，未实测一律落 `evidence_gap`。
   - 分类强制三组区分：**robots product token ≠ HTTP user-agent**（`Google-Extended` 是用途控制 token，无 HTTP 身份，只能记为控制事实）、**training ≠ search_index**（`GPTBot` vs `OAI-SearchBot`，两个独立控制面，分别探测分别判定）、**autonomous crawler ≠ user_initiated fetch**（`ChatGPT-User` 等用户触发取回，robots 可能不适用）。
   - probe 合法性由 taxonomy 的 `probe_validity` 约束：对 robots-only token 执行 HTTP 类 probe 属分类错误，结果无效。
   - 新增信号：`geo.discovery.block`、`geo.discovery.eligible`、`geo.discovery.control_recorded`、`geo.discovery.evidence_gap`。
2. **可冻结的 Prompt Universe（`geo_02`）**：`universe_id` + `universe_version` + `freeze_policy`；稳定 `prompt_id`；五维 metadata（Topic / Persona / Journey Stage / Intent / Archetype）；`metadata_hash = sha256(canonical_json(metadata))`（`notes` 不参与）；universe 级实体 alias 表与确定性归一化规则；`declared_coverage` 与缺口声明；`change_log` 与 `supersedes`。
   - 新增信号：`geo.prompt.coverage_gap`、`geo.prompt.metadata_drift`。
3. **可追溯的引用观测层（`geo_03`）**：每条 observation 强制包含 `prompt_id`、`engine{provider,product,model,mode}`、`executed_at`、`raw_response_ref{locator,content_sha256}`、`brand_mention{mentions[]}`、`citations[{citation_url,cited_domain,ownership}]`、`own_domain_citation`、`execution_status`（失败时含 `error`）。
   - 新增信号：`geo.brand.mention`、`geo.brand.absent`、`geo.citation.own_domain`、`geo.citation.competitor`、`geo.citation.gap`、`geo.observation.error`。

## 5. GEO 度量契约（6 个 canonical KPI）

| KPI | 公式 | 类型 | 状态 |
|---|---|---|---|
| Prompt Coverage | distinct(prompt_id, status=ok) / universe active prompt 数 | L2 instrument | 可实现 |
| Brand Mention Rate | distinct(obs, brand_mention=true) / distinct(obs, status=ok) | L3 observed | 可实现 |
| Own-domain Citation Rate | distinct(obs, own_domain_citation=true) / distinct(obs, status=ok) | L3 observed | 可实现 |
| Citation Share | own citation 行数 / 已解析 cited_domain 的 citation 行数 | L3 observed | 可实现（须按引擎分列） |
| Competitor Mention Share | 竞品实体 mention 数 / universe 实体 mention 数 | L3 observed | 可实现 |
| Intent-level Visibility | 按 `metadata.intent` 分组，分列 mention rate 与 own-citation rate | L3 observed | 可实现（每组须给 sample_size） |

强制追溯字段：`observation_ids`、`sample_size`、`engine_scope`、`model_scope`、`universe_version`、`window_start`/`window_end`、`error_count`。
强制规则：失败观测排除在分子分母之外；无 prompt universe 或无效观测时状态为 `unavailable`（**禁止填 0**）；禁止单一 0–100 GEO Score；禁止跨引擎综合分。

## 6. 哪些能力明确暂不实现

- llms.txt / Schema / FAQ 作为独立 GEO 模块 —— 归属 11 / 04，不新建。
- 生成式引擎排名类判断 —— 无可复现证据源。
- 跨引擎加权综合分与任何 composite GEO score。
- 未观测引擎/模型的可见性外推。
- dashboard、数据库、scheduler、API 服务等产品层能力。
- GEO-07 及以后（见第 10 节建议）。
- 生成式内容的“主观印象分”类指标（不可复现）。

---

## 7. 校验与回归结果（Validation / Regression）

### 7.1 执行的验证

| 验证 | 命令 | 结果 |
|---|---|---|
| 静态架构（SEO Core 未被破坏） | `python validators/validate_v1_4_architecture.py` | ERRORS 0 / WARNINGS 0 |
| canonical trace（既有 fixture） | `python scripts/validate_v1_5_architecture.py --trace tests/fixtures/SV-05/baseline.json --registry ownership_registry.yaml --runtime-context tests/fixtures/SV-05/runtime_context.json --trace-profile canonical_v1_5 --profile-source case_input` | PASS（exit 0） |
| canonical trace（负例未被放宽） | 同上，`--trace tests/fixtures/SV-05/mutation.json` | REJECT，`primary_code=ARCH-DEPENDENCY-001` |
| 混合 SEO+GEO canonical trace | 同上，`--trace tests/fixtures/geo/traces/mixed_seo_geo_trace.json --runtime-context tests/fixtures/geo/traces/mixed_seo_geo_runtime_context.json` | PASS，`primary_route` 仍为 `crawl_index` |
| GEO 契约与产物（GEO-01～06） | `python geo/scripts/validate_geo_extension.py …` | PASS（17 个 check 全 PASS） |
| GEO 定向回归（GEO-01～06 + SEO Core 兼容冒烟） | `python tests/run_geo_regression.py` | **78 / 78 PASS** |

### 7.2 GEO 回归总览（`tests/run_geo_regression.py`）

**实测结果：78 / 78 PASS。** 各模块 case 数：GEO-04 18 个 · GEO-05 17 个 · GEO-06 22 个 · GEO-01/02/03 与 SEO Core 兼容冒烟 21 个。逐模块明细见 7.2b / 7.2c / 7.2d。

| Case | 覆盖要求 | 结果 |
|---|---|---|
| `crawler_control_taxonomy` | crawler/control 分类自洽：21 个 controller、token 唯一、training/search 分离、robots-only token 无 HTTP 身份、用户触发取回不被当成可 robots 控制的爬虫、probe 合法性表、国内 crawler 身份来源分级 | PASS |
| `engine_surface_layering` | Engine → Surface 分层：17 引擎 / 24 surface 地址全局唯一、默认面必须存在、只有 api surface 可携带 API 通道、crawler token 只在引擎层级、同引擎必须能暴露不同通道、3 条分层规则齐备 | PASS |
| `cn_engine_registry` | 国内 AI Engine Registry：9 个国内引擎全部登记、Claude / Gemini / Grok 已登记、区域/通道/crawler 交叉引用自洽、API surface 必须有官方文档、无 crawler 身份的引擎必须写明 robots 限制 | PASS |
| `deepseek_observation_capability` | DeepSeek 观测能力修正：消费者面 manual-only、官方 API 为纯模型 API 无检索通道、引擎级不得声称确定性通道；2 个负例被拒（用 API surface 观测、把 manual 观测挂到 API surface） | PASS |
| `verified_dates_and_ua_policy` | 复核时效与 UA 版本化策略：全部引擎与 controller 在 180 天时效内、日期不得为未来、稳定 token 与版本化 UA 串必须区分、router trigger 不得使用 UA 串 | PASS |
| `cn_engine_citation_observation` | 国内引擎观测：8 ok / 3 failed 全部可追溯到各自原始响应、必须标注 engine_id + surface_id + 通道、观测地址必须在注册表内、国内/海外指标分列且互不污染；4 个负例被拒 | PASS |
| `ai_crawler_blocked` | AI crawler blocked：训练面（GPTBot）与检索面（OAI-SearchBot）各自独立成条、Google-Extended 记为用途控制而非访问状态、超时仍为证据缺口；6 个负例被拒（无片段阻断 / 同 pair 矛盾 verdict / 对 robots-only token 做 HTTP 探测 / 把用途控制报成阻断 / UA 与 taxonomy 不符 / 用 robots 判用户触发取回被阻断） | PASS |
| `ai_crawler_allowed` | AI crawler allowed：两控制面分别判定、用途控制无 HTTP 观测、未验证的 UA 模式不得变成渲染结论、eligible 不得带缺失 probe、eligible 不得发 control_recorded 信号 | PASS |
| `prompt_universe_metadata_consistency` | metadata 一致性、哈希可复现、漂移检测、冻结不可原地改 | PASS |
| `prompt_universe_coverage_gap` | 覆盖缺口识别（声明格子无 prompt） | PASS |
| `brand_alias_normalization` | 别名归一化（法律后缀 / 大小写 / 分隔符 / 空格）与冲突硬失败 | PASS |
| `own_domain_citation` | 自有域名引用、URL 原样保存、无引用行不得声称引用 | PASS |
| `competitor_citation` | 竞品域名引用、citation share、禁止市场份额解读 | PASS |
| `citation_gap` | 引用缺口（双侧举证、失败观测不得算缺口） | PASS |
| `raw_response_traceability` | 14/14 ok observation 逐条按 sha256 复核；KPI 必须可回溯 | PASS |
| `failed_observation_and_unavailable_provider` | 失败观测 / provider 不可用：排除出分子分母、错误数单列 | PASS |
| `kpi_contract_guardrails` | 6 个 KPI 冻结、小样本不得作结论、composite score 不可表达、unavailable 不得填值 | PASS |
| `geo_extension_end_to_end` | 静态契约 + taxonomy + engine registry + 2 discovery assessments + universe + observations + KPI 整体校验 | PASS |

### 7.2b GEO-04 回归覆盖（18 个 case，其中 2 个为反事实：`gd_diag_cf01` / `gd_diag_cf02`）

| Case | 覆盖要求 | 结果 |
|---|---|---|
| `geo04_contract_and_taxonomy` | GEO-04 契约自洽；11 个 failure mode、9 个比较维度按序声明；Schema/FAQ/llms.txt/内容长度在禁止推理清单中；confidence 不由 mode 导出；12 条 handoff 路由 | PASS |
| `geo04_discovery_blocked` | DISCOVERY_BLOCKED 必须引用 GEO-01 的 blocked verdict；无评估证据时报错；评估显示可达时报错 | PASS |
| `geo04_intent_mismatch` | 意图不匹配（页面职责 vs prompt 意图）；竞争方占优维度 < 3，因此不得判 COMPETITOR_SOURCE_SUPERIOR；路由到 15 | PASS |
| `geo04_answer_gap` | 答案要素缺口由结构化 profile 逐要素支撑；要素补齐后必须撤销；维度反而利于目标时必须撤销 | PASS |
| `geo04_weak_evidence` | 证据/出处薄弱来自 profile 的 `unattributed_claim`；Schema 不得被记作出处 | PASS |
| `geo04_extractability_weak` | 可摘录性以段落自足性与结构信号表述；显式拒绝"内容太长"解释；未检索反证 → low | PASS |
| `geo04_entity_ambiguous` | 实体歧义来自观察到的命名冲突；深层分析 deferred 到 GEO-05；无任何权威度评分 | PASS |
| `geo04_competitor_first_party_evidence` | 竞争方 6 维度占优、目标保留 1 个真实优势；三方画像齐备 → high；反证必须存在 | PASS |
| `geo04_freshness_gap` | 时效落后基于真实日期证据；并行 ANSWER_GAP 作为 secondary；移除日期证据后必须撤销 | PASS |
| `geo04_external_corroboration_gap` | 第三方印证只统计观测中实际出现的来源；路由到 18 | PASS |
| `geo04_competitor_source_superior` | 同一 mode 在缺少第三方证据时降为 medium；占优维度跌到 3 以下必须拒绝 | PASS |
| `geo04_multi_failure` | 3 个 failure mode 并存且各有独立可比维度与不同 Owner，不合并为单一结论 | PASS |
| `geo04_unresolved_when_insufficient` | 两条 UNRESOLVED 路径（无可比维度 / 观测不可追溯）；不得夹带具体 mode；强制 concrete mode 被拒 | PASS |
| `geo04_surface_isolation` | 同引擎不同 surface 结论冲突时分别成立；跨 surface 引用 profile 或 evidence 被拒；静默冲突被拒 | PASS |
| `geo04_mixed_seo_geo_handoff` | 混合场景按 `geo_01 → 09 → 08` 顺序交接；GEO-04/05/06 均声明为独立模块，GEO-05/06 已注册，`geo_entity_authority` / `geo_measurement` 分别由 `geo_05` / `geo_06` 持有且为 active | PASS |
| `geo04_authority_gap_guardrails` | AUTHORITY_GAP 只作 handoff 路由；`topic_authority` 只给相对观察；全部诊断不得夹带外部权威指标 | PASS |
| `geo04_counterfactual_changes_outcome` | **反事实 1**：把缺失要素补到目标、移除竞争方出处后，`ANSWER_GAP`/medium → `UNRESOLVED`/unresolved（同 prompt、同 engine、同 surface，仅证据变化）；**反事实 2**：目标改为纯客户端渲染后 `EXTRACTABILITY_WEAK` → `UNRESOLVED`/`09`，且该 mode 被校验器拒绝 | PASS |
| `geo04_end_to_end` | 17 条诊断 / 10 个 primary mode 全通过；每条绑定观测的 engine+surface；每条 9 维齐全 | PASS |

**反事实证明非模板化**：两个反事实变体保持 prompt / engine / surface 不变，只改 evidence，结论与 confidence 均发生变化（`ANSWER_GAP/medium → UNRESOLVED`、`EXTRACTABILITY_WEAK/low → UNRESOLVED`）。

### 7.2c GEO-05 回归覆盖（17 个 case，其中 1 个为反事实：`geo05_counterfactual_changes_outcome`）

| Case | 覆盖要求 | 结果 |
|---|---|---|
| `geo05_contract_and_taxonomy` | 14 个 failure mode、12 个维度、三类证据不可互替、禁止 backlink/Domain Authority/Schema/Wikipedia 推理、8 条 handoff 路由、GEO-04 入口点 | PASS |
| `geo05_router_and_signal_wiring` | 路由 / 8 个 `geo.*` signal / ownership（geo_05 转 active、geo_06 保持 reserved）/ router escalation 一致 | PASS |
| `geo05_brand_alias_conflict` | 品牌别名冲突被识别；可归并的别名不得被当作冲突 | PASS |
| `geo05_relationship_ambiguity` | 品牌—产品—组织关系互斥被识别；静默矛盾被拒绝 | PASS |
| `geo05_author_identity_unverifiable` | 作者/机构身份不可验证被识别；身份可验证时该 mode 必须被拒 | PASS |
| `geo05_self_claim_only` | 只有营销 self-claim 时判 SELF_CLAIM_ONLY 且 confidence 上限 low；必须证明已检索；出现一手资产即失效 | PASS |
| `geo05_original_research_without_corroboration` | 有原创研究但无独立印证被识别；补上真实独立来源即失效 | PASS |
| `geo05_corroboration_not_independent` | 付费/同源转述不计入印证；`shared_origin_refs` 必须记录；把非独立来源计为印证被拒 | PASS |
| `geo05_competitor_first_party_stronger` | 竞品一手数据更强被识别，且必须指出目标方占优/打平维度；"全面更强"被拒 | PASS |
| `geo05_coverage_breadth_weak_evidence` | 覆盖广但证据弱被识别；广度偏向目标方时该 mode 被拒；页面数量不得作为权威证据 | PASS |
| `geo05_authority_signal_conflict` | 权威维度方向相反时保留冲突；只列强项或无 conflict_pairs 被拒 | PASS |
| `geo05_insufficient_evidence_unresolved` | 证据不足输出 UNRESOLVED；出现可比证据后 UNRESOLVED 被拒 | PASS |
| `geo05_metric_proxy_rejected` | Domain Authority / DR-UR / backlink 数量作为权威证据一律被拒 | PASS |
| `geo05_geo04_handoff` | GEO-04 → GEO-05 handoff 保持父级 engine/surface/prompt 作用域；非入口 mode 被拒 | PASS |
| `geo05_scope_isolation` | 跨 observation、跨 market/locale、不可追溯观测三种越界全部被拒 | PASS |
| `geo05_counterfactual_changes_outcome` | 只改证据即可改变 failure mode 与 confidence；旧结论在证据变化后被拒 | PASS |
| `geo05_end_to_end` | 13 条 diagnosis × 12 维度、作用域绑定、trace 回写、禁止的指标代理全局扫描 | PASS |

### 7.2d GEO-06 回归覆盖（22 个 case，其中 2 个为反事实）

| Case | 覆盖要求 | 结果 |
|---|---|---|
| `geo06_contract_and_taxonomy` | 4 个变化分类、4 级归因阶梯、6 个 canonical KPI 复用、4 个新增增长指标、7 个优先级维度、商业价值三态、禁止 composite | PASS |
| `geo06_router_and_signal_wiring` | 路由 / 7 个 `geo.measurement.*` signal / ownership（geo_06 转 active）/ 无任何 reserved domain | PASS |
| `geo06_baseline_post_comparison` | baseline 与 post 正常比较；指标值由 raw observations 重算，自报值被拒 | PASS |
| `geo06_universe_version_mismatch` | Prompt Universe 版本不同不得直接比较；两个方向都被拒 | PASS |
| `geo06_surface_mismatch` | API 与 consumer surface 不得互相替代或合并 | PASS |
| `geo06_single_fluctuation` | 低于 materiality 的波动不得判改善；单观测指标不得决定分类 | PASS |
| `geo06_insufficient_sample_inconclusive` | 样本不足输出 inconclusive + 补齐清单；不得记录 success | PASS |
| `geo06_controlled_experiment` | 有对照组可达 experimental_evidence；单窗口不得升为 causal_claim | PASS |
| `geo06_no_control_association_only` | 无对照组归因上限 association、confidence 上限 low；claim 更高层级被拒 | PASS |
| `geo06_guardrail_blocks_success` | 护栏恶化阻断成功；提及上升而自有引用未改善被识别为护栏 | PASS |
| `geo06_competitor_share_shift` | 竞品份额同变；份额下降不得改写成改善 | PASS |
| `geo06_business_point_estimate` | 输入齐备给点值（必须带公式）；缺输入或无公式被拒 | PASS |
| `geo06_business_scenario_range` | 输入不足只给区间；同时给点值被拒 | PASS |
| `geo06_business_not_estimable` | 缺 referral / 收入时 not_estimable + 数据清单 | PASS |
| `geo06_upstream_handoff` | GEO-04 / GEO-05 诊断作为干预来源；不存在的上游 id 被拒 | PASS |
| `geo06_intervention_priority` | 7 维字典序排序真实生效；加权总分被拒 | PASS |
| `geo06_longitudinal_isolation` | 按 6 维切片；跨切片聚合被拒；< 2 窗口不得给趋势 | PASS |
| `geo06_counterfactual_evidence_changes_classification` | **反事实**：补上对照臂改变归因与 confidence；旧归因与样本塌陷后的 improved 被拒 | PASS |
| `geo06_counterfactual_baseline_changes_conclusion` | **反事实**：改 baseline / 削弱 control / 移除商业输入都改变结论；窗口自比被拒 | PASS |
| `geo06_mixed_seo_geo_growth` | mixed SEO + GEO 增长停在 association，SEO 侧判断交回注册 Owner | PASS |
| `geo06_forbidden_composites` | 单一 GEO 总分、加权总分、composite 措辞在文字/结构/契约三层都被拒 | PASS |
| `geo06_end_to_end` | 12 条 measurement 覆盖全部 4 个变化分类、作用域绑定与 trace 回写 | PASS |

### 7.3 SEO Core 兼容性冒烟（compatibility smoke，证明旧行为未变）

`seo_core_compatibility_smoke` 与 `seo_core_trace_validator_unchanged` 两个 case 覆盖：

1. **路由不变**：21 个既有 SEO route 的 `triggers` 与 `primary_modules` 与 GEO 之前**逐字比对**（硬编码基线）。
2. **Owner 不变**：20 个既有 capability domain 的 owner 逐个比对。
3. **模块身份不变**：01–20 仍在 `module_identity_registry.yaml`。
4. **验证器行为不变**：`scripts/validate_v1_5_architecture.py` 对 SV-05 基线仍 PASS、对 mutation 仍 REJECT 且错误码仍为 `ARCH-DEPENDENCY-001`。
5. **路由默认行为不变**：纯 SEO 任务仍路由到 SEO route；混合任务仍以 SEO container 为 `primary_route`，GEO 只作为附加 capability。
6. **静态验证器不变**：`validate_v1_4_architecture.py` 仍恰好识别 20 个 SEO 模块。

### 7.4 对 canonical trace 契约的改动

**无。** `canonical_trace_contract.yaml`、`canonical_trace_schema.json`、`runtime_invariants.yaml`、`minimal_execution_protocol.yaml`、`evaluation_policy.yaml`、`state_schema.json`、`trace_schema.json`、`forecast_input_contract_schema.json`、`domain_services/*`、`modules/01–20` **均未修改**。

---

## 8. 新增 / 修改文件清单与作用

### 8.1 新增（GEO 层，全部为新增文件）

| 文件 | 作用 |
|---|---|
| `geo/GEO_CAPABILITY_MODEL.md` | 能力分层与认识论边界（L1/L2/L3 互不蕴含）、Crawler/Control 三组区分、证据分级、确定性优先、禁止单一分数 |
| `geo/GEO_CRAWLER_TAXONOMY.yaml` | **GEO-01 的 crawler/control 分类 SSOT**：21 个 controller 的分类（training / search_index / user_initiated / archival）、robots product token 与 HTTP user-agent 的对应关系、用途控制范围、probe 合法性、国内/海外默认探测集合、官方来源与 last_verified |
| `geo/GEO_ENGINE_REGISTRY.yaml` | **GEO-02/GEO-03 的引擎注册表 SSOT**：17 个引擎（9 国内 + 8 海外）的 **Engine → Surface 两层结构**；每个 surface 的观测通道、确定性、搜索引擎 API 与来源字段、引用展示形态；引擎级的区域归属与 crawler 身份；verification policy（last_verified 语义、180 天时效、UA 版本化策略）与 7 条可观测性不对称硬约束 |
| `geo/GEO_MODULE_CONTRACT.yaml` | **A. GEO module contract 的 SSOT**：3 个模块的 scope / when_to_use / required_inputs / outputs / signals / owner / allowed_handoffs / evidence_requirements / guardrails / unsupported_claims |
| `geo/GEO_SIGNAL_REGISTRY.yaml` | **D. Signal Registry 的 SSOT**：11 个 `geo.*` signal 的 layer / owner / 触发条件 / 证据等级 / handoff / 可主张与不可主张边界 |
| `geo/GEO_METRIC_CONTRACT.yaml` | **E. GEO Measurement Contract 的 SSOT**：6 个 canonical KPI、追溯强制字段、聚合禁令、缺失数据处理 |
| `geo/GEO_MODULE_MAP.md` | 模块总览、signal 地图、GEO 内部依赖、与 SEO Core 的 Dependency/Handoff Map |
| `geo/schemas/geo_module_contract_schema.json` | module contract 的形状校验 |
| `geo/schemas/prompt_universe_schema.json` | prompt universe 文档形状（含 `metadata_hash`、`freeze_policy`、alias 表） |
| `geo/schemas/geo_citation_observation_schema.json` | observation 形状；强制 ok 必须有 raw response、失败必须无 brand/citation 结论 |
| `geo/schemas/geo_discovery_assessment_schema.json` | 可发现性评估矩阵形状（含 `control_ref` / `control_scope` / `robots_controls`） |
| `geo/schemas/geo_crawler_taxonomy_schema.json` | crawler taxonomy 形状；robots-only token 必须无 HTTP 身份 |
| `geo/schemas/geo_engine_registry_schema.json` | engine registry 形状：引擎 → surface 两层结构，观测通道必须与厂商实际提供的能力一致 |
| `geo/schemas/geo_kpi_report_schema.json` | KPI 报告形状；ok 指标必须带 `observation_ids`，unavailable 必须有原因且值为 null |
| `geo/validators/__init__.py` | 校验器导出 |
| `geo/validators/geo_contract.py` | 确定性校验：静态契约一致性、crawler taxonomy 自洽性与接线、engine registry 区域/通道/crawler 交叉引用、universe 一致性/漂移、observation 可追溯性与引擎归属、KPI 与原始观测一致性、可发现性判定与 probe 合法性规则、KPI 计算与缺口计算 |
| `geo/scripts/validate_geo_extension.py` | 校验 CLI |
| `geo/scripts/refresh_universe_hashes.py` | 维护工具：重算 `metadata_hash`（与校验器共用同一实现） |
| `modules/geo_01_ai_discoverability.md` | GEO-01 专业作业指导 |
| `modules/geo_02_prompt_universe.md` | GEO-02 专业作业指导 |
| `modules/geo_03_citation_visibility.md` | GEO-03 专业作业指导 |
| `GEO_EXTENSION_ARCHITECTURE.md` | 本文件：架构、边界、复用与新增、验证结果、遗留问题、下阶段建议 |
| `tests/run_geo_regression.py` | **F.** GEO 定向回归 + SEO Core compatibility smoke |
| `tests/fixtures/geo/prompt_universe.json` | 冻结 universe fixture（5 active + 1 deprecated prompt、alias 表、覆盖声明） |
| `tests/fixtures/geo/raw_responses.json` | 原始响应存储 fixture（traceability 的复核对象） |
| `tests/fixtures/geo/observations.json` | 17 条 observation（14 ok + 3 失败） |
| `tests/fixtures/geo/kpi_report.json` | 6 个 KPI 的报告 fixture |
| `tests/fixtures/geo/discovery/assessment_eligible.json` | AI crawler allowed 场景 |
| `tests/fixtures/geo/discovery/assessment_blocked.json` | AI crawler blocked + evidence gap 场景 |
| `tests/fixtures/geo/traces/mixed_seo_geo_trace.json` | 混合 SEO+GEO canonical trace |
| `tests/fixtures/geo/traces/mixed_seo_geo_runtime_context.json` | 混合场景 runtime context |
| `tests/fixtures/geo/_generate_observations.py` | fixture 生成器（保证 `content_sha256` 与 raw response 一致） |

### 8.2 修改（仅 additive，均为注册表接线）

| 文件 | 改动 | 是否破坏向后兼容 |
|---|---|---|
| `router.yaml` | 新增 `geo_extension` 元数据块、`selection_precedence`、3 个 `geo_*` route、stage_2 的 `geo_signals` 组；`geo_discoverability` 的 triggers 补充 OAI-SearchBot / ChatGPT-User / Claude-SearchBot / PerplexityBot；stage_2 `rule` 追加一句说明 GEO signal 同样不得改写 primary_route | 否。既有 21 个 SEO route 的 key/triggers/primary_modules 与 stage_2 既有 signal 组逐字未变（有回归用例锁定） |
| `ownership_registry.yaml` | 新增 3 个 `geo_*` capability domain 与 `geo_extension` 说明块（含 ownership_boundary） | 否。仅新增 domain，既有 20 个 domain 未变 |
| `module_identity_registry.yaml` | 新增 `geo_01` / `geo_02` / `geo_03` 三个 module id 映射 | 否。仅新增条目，`source_sentinels` 与 `review_sink` 未变 |
| `SKILL.md` | 执行文件清单新增一行：显式 GEO 任务读取 `geo/` 契约文件 | 否。未改执行链、对象定义或评分原则 |
| `modules/geo_01_ai_discoverability.md` | 补充 crawler/control taxonomy 章节、`control_ref` / `control_scope`、probe 合法性与新的不支持主张 | 否。只改 GEO-01；GEO-02/03 与 SEO Core 未动 |
| `geo/GEO_MODULE_CONTRACT.yaml` / `GEO_SIGNAL_REGISTRY.yaml` / `GEO_MODULE_MAP.md` / `GEO_CAPABILITY_MODEL.md` | 同步 taxonomy 变更：新增 `crawler_taxonomy` 必需输入、`usage_control_findings` 输出、`geo.discovery.control_recorded` 信号、分类速查表 | 否。均为本阶段新增文件 |

**未修改**：`modules/01–20`、`modules/geo_02_prompt_universe.md`、`modules/geo_03_citation_visibility.md`、`domain_services/*`、`references/*`（含 `rule_fidelity_manifest.yaml`）、`canonical_trace_contract.yaml`、`canonical_trace_schema.json`、`runtime_invariants.yaml`、`minimal_execution_protocol.yaml`、`orchestration_core.yaml`、`ORCHESTRATION_CORE.md`、`evaluation_policy.yaml`、`state_schema.json`、`trace_schema.json`、`runtime_context_schema.json`、`forecast_input_contract_schema.json`、`scripts/*`、`validators/*`、`prompt_universe_schema.json`、`geo_citation_observation_schema.json`、`geo_kpi_report_schema.json`、GEO-02/03 的 fixtures 与 KPI 契约。

---

## 9. 当前未解决问题

1. ~~默认 AI user-agent 集合未固化~~ **已解决**：`GEO_CRAWLER_TAXONOMY.yaml` 的 `default_agent_set` 按国内/海外两组固化了默认探测集合，新增 agent 必须同时提供官方来源 URL 与 `last_verified` 日期，否则不得进入 `controllers`。
   - 残留缺口：`claude_searchbot`、`claude_user`、`moonshotbot` 厂商只公布产品串、没有可逐字节复现的 UA 模式，因此标记 `ua_pattern_verified: false`；对它们做 HTTP 探测时必须以 limitation 记录，不能声称 UA 精确匹配。
2. **国内 AI crawler 身份的可信度分级**：本阶段新增的 10 个国内 controller 中，只有 `baiduspider` 有厂商官方文档；`erniebot`、`yiyanbot`、`doubaobot`、`bytespider`、`qwenbot`、`tongyibot`、`aliyunbot`、`kimibot`、`moonshotbot` 均标记为 `vendor_reported`（来自第三方 crawler 资料库）。它们能支撑"待复核"结论，但不能写成已确认事实。这是当前最大的证据强度缺口。
3. **人工观测通道的覆盖率下限**：`quark_ai`、`metaso_ai`、`tiangong_ai` 与 `deepseek` 的消费者面没有已核实的官方 API，只能 `manual_session` / `browser_automation`。它们的 prompt coverage 天然偏低，目前没有规定"人工观测最少需要多少条才算可用"。
4. **`search_product` surface 缺官方通道**：`google_ai_overviews` 是搜索结果页内的 AI 答案面，没有与之对应的官方 API surface，只能浏览器自动化或第三方 proxy。第三方数据必须标 `proxy`，但"proxy 结果能否用于 KPI"尚未规定。
5. **AI 代理访问面与 WAF/CDN 归因**：实测只到"响应头显示被拦"，无法从 CDN 内部规则证明是哪条规则命中；taxonomy 提供了每个 controller 的拒绝签名（例如 `x-edge-action: bot-block`），但仍未定义标准化的归因升级路径。
6. **待逐字段复核的 API 返回结构**：智谱清言 `web_search`、Grok Live Search、Gemini grounding metadata 三处的来源字段名尚未逐字段核实，registry 已标 `pending_verification`，但还没有"复核完成"的验收动作定义。
7. **Agent / Engine 清单的时效性**：`last_verified` + 180 天阈值已经是可校验的规则，但复核本身仍是人工动作，没有自动化提醒或失败阻断。
8. **`geo.prompt.coverage_gap` 的双触发点**：建库阶段（`geo_02`）与观测阶段（`geo_03` 发现某 prompt 无有效观测）都会产生该信号，Owner 固定为 `geo_02`。跨阶段触发时如何避免噪声尚未定义收敛规则。
9. **观测顺序/时序偏差未建模**：prompt 执行顺序可能影响答案（会话上下文、限流）；当前只记录 `executed_at`，没有随机化执行顺序或 session 隔离的规范。
10. **样本量与置信区间**：contract 只强制 `sample_size` 与小样本标注，没有区间估计要求；跨引擎、跨 surface、跨区域合并已被禁止，但单 surface 小样本的结论强度仍依赖人工判断。
11. **alias 归一化的中文语义问题**：归一化是纯确定性字符串规则，对中文没有分词与简称处理（例如"阿里""阿里巴巴""通义"是不同实体还是同一实体需人工决定）；contract 用 `match_method: ambiguous` 记录但未定义消解流程。
12. **KPI 的时间可比性**：`window_id` 是自由字段，尚未定义"同一 prompt 在不同窗口的重跑"如何标记为可比序列。
13. **失败重试语义**：`error.retryable` 只是布尔标记，重试是否算新 observation（CiteGEO 明确"retry 不算新样本"）尚未规定。
14. **fixture 覆盖缺口**：`geo.prompt.metadata_drift` 与 `geo.observation.error` 仍只有定向 mutation 覆盖，没有独立产物 fixture；`browser_automation` 与 `search_product` 两条通道还没有 fixture 覆盖；多语言 locale 场景未覆盖。

---

## 10. 后续能力方向（GEO-01～06 均已实现）

**编号规则**：GEO-01～06 已全部落地并冻结，**不得复用**。后续任何新能力一律从 **GEO-07** 起编号，
且必须先证明它不属于 01～06 的任何 capability domain。

### 已实现（不再作为"建议"）

| 模块 | capability_domain | 状态 |
|---|---|---|
| GEO-01 | `geo_discoverability` | 已实现 |
| GEO-02 | `geo_prompt_universe` | 已实现 |
| GEO-03 | `geo_citation_visibility` | 已实现 |
| GEO-04 | `geo_citation_diagnostics` | 已实现 |
| GEO-05 | `geo_entity_authority` | 已实现 |
| GEO-06 | `geo_measurement` | 已实现 |

### GEO-07+ 候选方向（只给方向与理由，不写实现）

这些方向**目前没有 SSOT、没有 contract、没有 fixture**，因此不得在文档或输出中被当作已实现能力引用。

1. **答案份额与竞争结构分析**（跨 prompt 的份额与结构）：需要先把 GEO-06 的样本量与置信区间规范
   落到真实数据上，否则会引入不可验证的份额结论。
2. **引用就绪度的可复用检查清单**：与 Schema（11）、内容架构（04）、可访问性（08）高度重叠，
   必须先做重叠审计，只保留 11/04/08 未覆盖的判定项。
3. **多模态（图片 / 视频 / 语音）GEO 测量**：现有 canonical KPI 只覆盖文本引用。
4. **跨市场 / 多语言测量方法**：隔离机制已就绪（`market` / `locale`），但缺方法学与真实样本。

### 跨阶段建议（工程与数据侧）

- **优先补国内 crawler 的官方来源**：当前 10 个国内 controller 里有 9 个是 `vendor_reported`。
  应逐个向厂商文档/站长平台核实，把能升级的升级为 `official`；升级不了的要在交付物里保留"待复核"标注。
- **明确人工观测的最低可用标准**：为 `manual_session` 通道定义最少观测条数与重复次数，否则
  `quark_ai` / `metaso_ai` / `tiangong_ai` 的 prompt coverage 无法解释。
- **把 AI user-agent 清单的 `last_verified` 复核纳入常规运行**（registry 已建立，缺的是复核节奏）。
- **把「原生响应必须落盘后才允许统计」写成一条独立的 runtime invariant 条目**，让它在任何 GEO 产物中都可被确定性检查。
- **真实观测采集管道**：目前观测靠人工执行；这是所有下游指标的最大前置条件。
- **AI referral 归因口径**：GEO-06 从 scenario 升级到 point estimate 的前置条件。
- **统计功效与区间估计**：目前 `materiality` 是固定工程阈值，功效分析归 19。
- 保持 `geo.*` 命名空间不变；任何新增能力先回答"这条判断是否已由 08/09/11/04/03/geo_01～06 覆盖"，
  避免 GEO 变成第二套技术 SEO。
- 新增 agent 时严格遵守 taxonomy 的三组区分，尤其不要把新的厂商"用途控制 token"注册成 `http_agent`；
  新增引擎时必须同时更新 `GEO_ENGINE_REGISTRY.yaml` 与必要的 router trigger。

---

## 11. 变更记录

### 修订 7 —— GEO-06 度量、增长与实验闭环（GEO 核心模块收束）
- 新增 `geo/GEO_06_MEASUREMENT_TAXONOMY.yaml`（窗口可比性判据、4 个变化分类、归因四级阶梯、实验九项契约、7 维优先级模型、商业价值三态、longitudinal 切片隔离）。
- 新增 `geo/GEO_06_DIAGNOSIS.yaml`、`geo/GEO_06_MEASUREMENT_METHOD.md`、`modules/geo_06_measurement_growth.md`。
- 新增 `geo/schemas/geo_06_module_contract_schema.json`、`geo_measurement_schema.json`、`geo_intervention_priority_schema.json`。
- 新增 `geo/validators/geo_measurement.py`（静态契约 + measurement 记录 + intervention 优先级三层校验；KPI 一律由 `citation_visibility_metrics` 重算，不重定义口径）。
- 新增 `tests/fixtures/geo/measurement/`（138 条双窗口观测 / 12 条 measurement / 1 份 intervention 优先级清单，由 `_build_measurement.py` + `_cases.py` 确定性生成）。
- 新增 22 个 `geo06_*` 定向回归 case（含 2 个反事实）。
- **接线**：注册 `geo_06`、`geo_measurement` 由 reserved 转为 active、新增 `geo_measurement` 路由与 `geo_measurement` 信号组、`GEO_SIGNAL_REGISTRY.yaml` 增加 7 个 `geo.measurement.*` signal、`GEO_MODULE_CONTRACT.yaml` 增加 geo_06 契约。
- **新增 4 个增长指标**（不改动冻结的 6 个 canonical KPI）：`citation_gap_closed_rate`、`citation_share_delta_vs_competitor`、`visibility_stability`、`own_brand_mention_rate`（后者按自有实体解析，避免重定义 canonical 的 `brand_mention_rate`）。
- **未改动 SEO Core 01–20**；GEO-01～05 的失败模式、维度与置信度策略保持原样。

### 修订 6 —— GEO-05 实体、权威与来源可信度诊断
- 新增 `geo/GEO_05_ENTITY_AUTHORITY_TAXONOMY.yaml`（14 个 failure mode、12 个诊断维度、三类证据类型学、置信度派生、8 条 handoff 路由、GEO-04 入口点、canonical trace 回写要求）。
- 新增 `geo/GEO_05_DIAGNOSIS.yaml`、`geo/GEO_05_DIAGNOSTIC_METHOD.md`、`modules/geo_05_entity_authority.md`。
- 新增 `geo/schemas/geo_05_module_contract_schema.json`、`geo/schemas/geo_entity_authority_schema.json`、`geo/schemas/geo_entity_authority_diagnosis_schema.json`。
- 新增 `geo/validators/geo_authority.py`（静态契约 + 实体画像 + 权威诊断三层校验；`geo/validators/__init__.py` 与 CLI 追加 `--entity-profiles` / `--authority-diagnoses` / `--geo04-diagnoses`）。
- 新增 `tests/fixtures/geo/authority/`（19 个观测 / 26 个实体画像 / 13 条诊断 / 1 条 GEO-04 父诊断，由 `_build_authority.py` + `_cases.py` 确定性生成）。
- 新增 17 个 `geo05_*` 定向回归 case（含 1 个反事实）。
- **接线**：`module_identity_registry.yaml` 注册 `geo_05`；`ownership_registry.yaml` 把 `geo_entity_authority` 由 reserved 转为 active；`router.yaml` 增加 `geo_entity_authority` 路由与 `geo_entity` / `geo_authority` 信号组；`GEO_SIGNAL_REGISTRY.yaml` 增加 8 个 `geo.entity.*` / `geo.authority.*` signal；`GEO_MODULE_CONTRACT.yaml` 增加 geo_05 模块契约并把 geo_04 → geo_05 的 handoff 由 deferred 改为 open。
- **未改动 SEO Core 01–20 的业务规则**；GEO-01～04 的失败模式、维度、置信度策略保持原样，只更新了 geo_04 指向 geo_05 的交接状态与措辞。

### 修订 5 —— 发布工程与文档中文化（无 schema / taxonomy / fixture 改动）
- **运行时产物永久排除**：新增 [`.gitignore`](.gitignore)、[`MANIFEST.in`](MANIFEST.in) 与 [`RELEASE.md`](RELEASE.md)。三层执行：版本控制层（`.gitignore`）、打包层（`MANIFEST.in` 的 `recursive-exclude` / `prune`）、发布校验层（`scripts/check_release_artifacts.py`）。排除范围含 `__pycache__/`、`*.py[cod]`、测试缓存、编辑器产物、本地虚拟环境与发布中间产物。
- **发布前审计脚本**：新增 [`scripts/check_release_artifacts.py`](scripts/check_release_artifacts.py)，扫描仓库树内的运行时产物、校验排除规则存在性、校验发布必需文件与模块齐备；退出码 0 才允许发布。
- **文档中文化**：把用户可见文档中的英文小标题改为中文优先（`GEO_EXTENSION_ARCHITECTURE.md`、`ORCHESTRATION_CORE.md`、`SKILL.md`、`GEO_CAPABILITY_MODEL.md`、`GEO_MODULE_MAP.md`、`GEO_04_DIAGNOSTIC_METHOD.md`、`modules/README.md`）。固定技术名词、schema key、字段名与模块 ID 保留英文。仓库内不存在跨文档英文锚点，因此改标题不影响任何链接。
- **范围声明同步**：把"不实现 GEO-04～06"更新为"已实现 GEO-01～04、不实现 GEO-05～07"，并把下一阶段建议由 GEO-04～06 重编号为 GEO-05～07（因 GEO-04 已落地）。
- **未改动**：全部 `geo/schemas/*.json` 与 `canonical_trace_schema.json` 等 schema key；`GEO_04_CITATION_FAILURE_TAXONOMY.yaml`、`GEO_SIGNAL_REGISTRY.yaml`、`GEO_MODULE_CONTRACT.yaml`、`GEO_CRAWLER_TAXONOMY.yaml`、`GEO_ENGINE_REGISTRY.yaml`、`GEO_METRIC_CONTRACT.yaml` 的规则内容；`router.yaml` / `ownership_registry.yaml` / `module_identity_registry.yaml`；`geo/validators/*.py`；`tests/run_geo_regression.py` 与 `tests/fixtures/**` 全部 fixture。
  - 说明：本修订只新增发布工具与改文档标题。`GEO_04_CITATION_FAILURE_TAXONOMY.yaml` 中的 `requires_favors` 字段属于**上一修订（4）**的 GEO-04 构建内容，不在本修订范围内。

### Phase 1 修订 4 —— GEO-04 Grounding & Citation Diagnostics
- 新增 `geo/GEO_04_CITATION_FAILURE_TAXONOMY.yaml`（failure mode、9 维比较口径、置信度派生规则、handoff map）与 `geo/GEO_04_DIAGNOSTIC_METHOD.md`（7 步诊断流程与维度操作口径）。
- 新增 `geo/GEO_04_DIAGNOSIS.yaml` 与 `geo/schemas/geo_04_module_contract_schema.json`：GEO-04 的模块契约（scope / inputs / outputs / signals / handoff / evidence / guardrail）。
- 新增 `geo/schemas/geo_source_profile_schema.json` 与 `geo/schemas/geo_diagnosis_schema.json`：来源画像与诊断记录的形状。
- 新增 `geo/validators/geo_diagnostics.py`：GEO-04 确定性校验（契约自洽、taxonomy 自洽、诊断合法性、证据方向性、surface 隔离、反证要求）。
- 新增 `modules/geo_04_citation_diagnostics.md` 专业作业指导。
- 新增 3 个 GEO-04 信号：`geo.diagnosis.failure_mode`、`geo.diagnosis.unresolved`、`geo.diagnosis.surface_conflict`。
- 新增 router 路由 `geo_citation_diagnostics`（primary module `geo_04`）与 stage_2 的 `geo_diagnosis` 信号组。
- 注册 `geo_04` capability domain 与 module id；把 `geo_entity_authority`（GEO-05）与 `geo_measurement`（GEO-06）注册为 **reserved domain**，使 deferred handoff 可被校验，同时不实现这两个模块。
- 新增 18 条观测、37 个来源画像、17 条诊断的 fixtures（`tests/fixtures/geo/diagnostics/`）与确定性生成器。
- 新增 14 个 GEO-04 回归 case（含 2 个反事实）；回归总数 21 → **39，全部 PASS**（该数字是修订 4 时点的快照；当前总计见第 7.2 节）。
- **（修订 1 历史记录）当时未实现 GEO-05/06，未新增 dashboard / 数据库 / scheduler / GEO 总分**；SEO Core 01–20 未改动，GEO-01～03 的业务定义未改写（仅在注册表层面追加 GEO-04 的接线）。
- 本轮同时修正两处实现缺陷：来源画像 id 跨诊断复用的缺陷（改为每个诊断独立 id 空间），以及 surface 冲突检测只检查第一个候选观测的缺陷（改为检查全部同引擎他 surface 观测）。

### Phase 1 修订 3 —— Engine → Surface 分层、DeepSeek 修正、新增 Claude / Gemini / Grok
- **Engine → Surface 分层**：`GEO_ENGINE_REGISTRY.yaml` 由"引擎 = 观测单位"改为两层结构。引擎级保留 `region` / `engine_type` / `crawler_identity` / `crawler_refs`；观测单位下沉到 `surfaces[]`（`surface_id` / `surface_type` / `observation_method` / `determinism` / `available` / `citation_display` / `search_api`）。观测地址统一写作 `<engine_id>::<surface_id>`。
  - 新增 `surface_types`：`consumer_app` / `api` / `search_product`。
  - 新增硬约束 `no_cross_surface_merge` 与 `token_is_engine_level`；`no_api_equals_consumer` 由文档规则升级为**结构强制**（API 通道只能挂在 `api` surface 上）。
  - observation 的 `engine` 增加 `surface_id` / `surface_type`，校验器强制观测与 surface 记录一致，并要求 ok 观测必须能定位到具体 surface。
  - 引擎级 `observation_method` / `determinism` 作为默认 surface 的投影，由 `_sync_engine_summary.py` 机械同步，校验器强制两者不得矛盾。
- **修正 DeepSeek observation capability**：此前把 DeepSeek 记为 `vendor_search_api` 是错的。核实结论：官网新闻页记录了"联网搜索上线官网"（搜索能力在**消费者产品侧**），而官方 API 文档（`https://api-docs.deepseek.com/`）只描述 chat completion，**未见任何内置联网搜索工具或检索参数**。
  - `deepseek::consumer_app` → `manual_session`（唯一可观测通道）
  - `deepseek::api` → `unavailable`，`citation_display: none_documented`，但保留官方文档引用以说明核实依据
  - 引擎级 `observation_method` 从 `vendor_search_api` 降为 `manual_session`，`determinism` 降为 `manual`
  - 新增回归 `deepseek_observation_capability`，含 2 个负例（用 API surface 观测、把 manual 观测挂到 API surface）
- **新增 Claude / Gemini / Grok**：
  - `claude`（Anthropic）：`consumer_app` + `search_api`（server-side web search tool），crawler official
  - `google_gemini`（Google）：`consumer_app` + `search_api`（Grounding with Google Search），与 `google_ai_overviews` 明确分开
  - `grok`（xAI）：`consumer_app` + `search_api`（Live Search），crawler token 未公开 → `crawler_identity: undocumented`
  - 同时把 `google_ai_overviews` 修正为 `search_product` surface（搜索结果页内的 AI 答案面，**没有**对应官方 API surface），此前把它记为 `vendor_search_api` 是错的
  - 顺带补入 `zhipu_qingyan`（智谱清言），使国内引擎由 9 个增至 10 个
  - 引擎总数 13 → 17（国内 10 + 海外 8，`tongyi_ai` / `kimi` 计为 `cn_and_global`）
- **更新 verified dates 与 UA versioning policy**：
  - 新增 `verification_policy`：`last_verified` 语义（人工对照厂商官方材料的复核日期）、`stale_after_days: 180`、超期后果
  - 新增 `user_agent_versioning`：区分 **稳定 product token**（`GPTBot` / `Bytespider` / `Baiduspider`）与 **不稳定的版本化 UA 串**（`GPTBot/1.3` / `Chrome/131.0.0.0`）；判定以 token 为准，UA 只是快照
  - 全部 engine 与 controller 的 `last_verified` 更新为 `2026-10-09`（21 条 controller + 17 条 engine）
  - 校验器新增时效检查：未来日期报错，超期报 warning；新增回归 `verified_dates_and_ua_policy`
- **清理**：删除本次使用的一次性脚本（`_add_engine_status.py`、`_rewrite_engine_validator.py`、`_sync_engine_summary.py`）与全部 `__pycache__`。
- 回归总数 18 → **21，全部 PASS**。GEO-02 的 universe / 维度 / KPI 契约与 SEO Core 业务规则未改动。

### Phase 1 修订 2 —— 国内 AI Engine Registry
- 新增 `geo/GEO_ENGINE_REGISTRY.yaml`（+ `geo/schemas/geo_engine_registry_schema.json`）：登记 13 个引擎，其中 **9 个国内**（豆包、腾讯元宝、DeepSeek、通义千问、文心一言、Kimi、夸克 AI 搜索、秘塔 AI 搜索、天工 AI）与 4 个海外基线（ChatGPT、Google AI Overviews、Copilot、Perplexity）。
- 引入 `region` / `observation_method` / `determinism` / `search_api` / `citation_display` / `crawler_identity` 等字段，并写入 5 条**可观测性不对称**硬约束：`no_api_equals_consumer`、`no_aggregate_across_regions`、`no_cross_engine_substitution`、`method_must_be_reported`、`region_of_observation`。
- **核实到官方联网搜索 API 的国内引擎**：豆包（火山方舟）、腾讯元宝（元宝搜索 SearchPro，返回 `Pages[].url` 与 `authority_level`）、通义千问（百炼 DashScope `enable_source` / Responses `web_search_call.action.sources`）、Kimi（`POST /v1/tools/search|search_pro|fetch`）、文心一言（千帆百度 AI 搜索）、DeepSeek（官方 API）。
- `GEO_CRAWLER_TAXONOMY.yaml` 新增 10 个国内 controller：`baiduspider`（官方文档）、`erniebot`、`yiyanbot`、`doubaobot`、`bytespider`、`qwenbot`、`tongyibot`、`aliyunbot`、`kimibot`、`moonshotbot`（其余为 `vendor_reported`）。
- 新增 `classification_confidence: vendor_reported` 等级，使"第三方资料库记载"与"厂商官方文档"可区分；taxonomy 校验对非官方来源输出 warning。
- `geo_citation_observation_schema.json` 的 `engine` 增加 `engine_id` / `region` / `observation_method` / `executed_region` / `channel_note`；校验器强制 observation 与引擎注册表一致。
- router：`geo_discoverability` 与 `geo_citation_visibility` 的 triggers 增加国内 crawler token 与国内引擎名称。
- 新增 fixtures：`observations_cn.json`（10 国内 + 1 海外，8 ok / 3 failed）、`raw_responses_cn.json`、`_generate_cn_observations.py`。
- 新增 regression：`cn_engine_registry`、`cn_engine_citation_observation`；回归总数 16 → **18，全部 PASS**。
- 未改动 GEO-02 的 universe / 维度 / KPI 契约与既有 SEO Core 业务规则；GEO-03 只增加了引擎归属字段与校验，metric 定义未变。

### Phase 1 修订 1 —— GEO-01 crawler/control taxonomy 修正
- 新增 `geo/GEO_CRAWLER_TAXONOMY.yaml`（+ `geo/schemas/geo_crawler_taxonomy_schema.json`）作为 GEO-01 的分类 SSOT。
- 加入 `OAI-SearchBot`，并把 OpenAI 控制面拆成 `gptbot`（training）与 `oai_searchbot`（search_index）两个独立 controller。
- 明确 `google_extended` 为 **robots product token，非 HTTP user-agent**：`agent_kind: robots_only_token`、`http_user_agent: null`、约束 Gemini 训练/grounding、不影响 Googlebot 抓取与索引；只能产出 `control_recorded`，禁止任何 HTTP 探测。
- 新增信号 `geo.discovery.control_recorded`；`geo_01` 的 probe 增加 `control_ref` / `control_scope`；新增 `robots_controls` 记录块。
- fixtures 与 regression 同步更新：新增 `crawler_control_taxonomy` case，`ai_crawler_blocked` / `ai_crawler_allowed` 重写，负例从 2 个增加到 6 个。
- 未改动 GEO-02 / GEO-03 及其 schema、fixture、KPI 契约；未改动 SEO Core 任何业务规则。
- 清理仓库内全部 `__pycache__` 目录。

---

## 12. 引用来源

本阶段新增的国内引擎与 crawler 事实来自以下**厂商官方**来源（其余 crawler 身份来自第三方 crawler 资料库，已在 registry 中标记为 `vendor_reported`）：

- 腾讯云 · 元宝搜索 SearchPro API：<https://cloud.tencent.com/document/product/1806/121811>
- 阿里云百炼 · 联网搜索（含来源返回字段）：<https://www.alibabacloud.com/help/zh/model-studio/web-search>
- Kimi 开放平台 · 联网搜索（`/v1/tools/search` 等独立接口）：<https://platform.kimi.com/docs/guide/use-web-search>
- 百度 · robots.txt 协议与 Crawl-delay：<http://www.baidu.com/search/robots.html>
- 百度千帆 · 百度 AI 搜索：<https://cloud.baidu.com/doc/qianfan/s/2mh4su4uy>
- 火山引擎 · 豆包搜索 / Web Search：<https://www.volcengine.com/docs/82379/1399159>
- OpenAI · Bots（GPTBot / OAI-SearchBot / ChatGPT-User）：<https://developers.openai.com/api/docs/bots>
- Anthropic · 三个 web crawler 说明：<https://privacy.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler>
- Perplexity · crawlers：<https://docs.perplexity.ai/docs/resources/perplexity-crawlers>
- Google · crawlers 与 fetchers 总览：<https://developers.google.com/search/docs/crawling-indexing/overview-google-crawlers>
- Common Crawl · CCBot：<https://commoncrawl.org/ccbot>
- 第三方 crawler 身份资料（用于 `vendor_reported` 条目，需厂商文档复核）：<https://www.xseek.io/docs/doubao-user-agents>、<https://www.xseek.io/docs/qwen-user-agents>、<https://www.xseek.io/docs/kimi-user-agents>、<https://www.xseek.io/docs/baidu-ernie-user-agents>、<https://www.xseek.io/docs/deepseek-user-agents>
- DeepSeek · 官方 API 文档（用于确认 API 侧无联网搜索工具）：<https://api-docs.deepseek.com/>
- DeepSeek · 官方新闻（联网搜索上线官网）：<https://api-docs.deepseek.com/zh-cn/news/news1210/>
- Anthropic · web search tool：<https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool>
- Google · Grounding with Google Search（Gemini API）：<https://ai.google.dev/gemini-api/docs/google-search>
- xAI · Live Search：<https://docs.x.ai/docs/guides/live-search>
- 智谱开放平台（BigModel）：<https://docs.bigmodel.cn/>
