geo_01_ai_discoverability — GEO-01｜AI Discoverability（AI 可发现性）

【Phase 1 模块边界】
- Module ID：`geo_01`（人类别名 GEO-01）
- 专业职责：AI/搜索代理访问面（AI crawler access）
- Layer：`L1_discoverability`
- Capability domain：`geo_discoverability`（`ownership_registry.yaml` 中注册的 Owner 为 `geo_01`）
- Contract：`geo/GEO_MODULE_CONTRACT.yaml` 中 `module_id: geo_01` 条目是本模块 scope / inputs / outputs / signals / handoff / evidence / guardrail 的 Single Source of Truth；本文件不重复定义这些内容。
- 全局路由、证据校准、Owner/Handoff、Dedup、Dependency、Context 与 Trace 遵循 `minimal_execution_protocol.yaml` 与 `runtime_invariants.yaml`；本模块不得重定义这些规则。
- Signal 触发条件与可主张边界见 `geo/GEO_SIGNAL_REGISTRY.yaml`；本文件不重复 signal 定义。
- **Crawler / control taxonomy 见 `geo/GEO_CRAWLER_TAXONOMY.yaml`**：agent 分类、robots product token 与真实 HTTP user-agent 的对应关系、probe 合法性都以该文件为准；本文件不复制其内容。

【核心认识论纪律】
**Discoverability ≠ Citation Readiness ≠ Observed Citation。**
本模块只回答一个问题：**在本次探测的时间、代理与用途范围内，AI/搜索代理能否取得这些 URL 的内容。**
它不回答“会不会被引用”，也不产生任何可见性指标。没有观测就不得推断引用行为。

【Crawler / control taxonomy：三组必须分开的东西】

1. **robots product token ≠ HTTP user-agent。**
   `Google-Extended` 是 robots.txt 里的**用途控制 token**，没有独立的 HTTP 请求身份——真正的抓取由 `Googlebot` 完成，它只约束内容被用于 Gemini 训练与 grounding。
   因此：不得对它执行 `http_status` / `waf_probe` / `render_snapshot`；不得据它推断 Googlebot 的抓取、索引、排名是否受影响。它的结论只能记为 `geo.discovery.control_recorded`。

2. **training ≠ search_index。**
   同一厂商的训练抓取与检索抓取是**两个独立控制面**：
   - `GPTBot` = training（是否允许进入生成式基础模型训练语料）
   - `OAI-SearchBot` = search_index（是否允许出现在 ChatGPT 搜索结果与答案中）
   - `ClaudeBot` = training，`Claude-SearchBot` = search_index
   - `PerplexityBot` = search_index（官方明确不用于基础模型训练）
   - `CCBot` = archival（开放语料归档，下游可能被用于训练，结论要按归档口径表述）
   必须**分别探测、分别判定、分别成条**；一个被抓取/被禁止不得推断另一个的状态。

3. **autonomous crawler ≠ user_initiated fetch。**
   `ChatGPT-User`（以及 `Claude-User`、`Perplexity-User`）是**用户当场触发**的取回，`robots.txt` 规则可能不适用（`Perplexity-User` 官方说明一般忽略 robots）。
   这类条目的 `robots_controllable` 为 false 时，**不得**用 robots Disallow 判定其为"被阻断"，只能报告"robots 可控性"事实。

【与 SEO Core 的边界（禁止重复造已有能力）】
- 最终 indexability / canonical / robots / Sitemap 判定：归 `08`，本模块只提交实测事实。
- HTML/DOM 渲染差异、客户端路由、hydration 的最终渲染结论：归 `09`。
- Schema / 结构化数据：归 `11`。性能：归 `10`。内部链接：归 `14`。
- 本模块**不**重新实现上述任何技术 SEO 能力，也**不**把 `llms.txt`、Schema、FAQ 单独做成 GEO 模块。

【工作流定位】
- 能力定位：AI/搜索代理可访问性实测与阻断归因（按 control scope 分开）。
- 上游输入：`geo/GEO_CRAWLER_TAXONOMY.yaml`、目标 URL 清单、AI agent 集合、robots.txt 原文、实测抓取结果、可选渲染快照与 indexability 控制事实。
- 本 Prompt 输出：per-URL / per-agent / per-control-scope 的可发现性矩阵、阻断发现、用途控制记录、证据缺口、SEO Handoff 事实。
- 下游衔接：`08`（indexability）、`09`（rendering）。

【输入】
目标 URL：[填写，至少覆盖代表性模板与关键转化页]
AI agent 集合：[填写 `control_ref`（taxonomy 中的 agent_id）；未声明时使用 `GEO_CRAWLER_TAXONOMY.yaml` 的 `default_agent_set` 并显式标注 `declared: false`]
robots.txt：[抓取时间 + 原文或可复核引用]
抓取观测：[每个 (url, agent) 的 HTTP 状态、最终 URL、响应头、正文可取得性]
渲染快照：[原始 HTML 与渲染后 DOM；缺失时该维度记为证据缺口]
自有域名清单：[用于 canonical 分歧比对]

【探测维度（全部 probe 都要落证据，并标注 control_ref 与 control_scope）】
1. `robots_fetch`：实际抓取 robots.txt，记录获取时间与原文。禁止仅凭第三方摘要或缓存判定。
2. `robots_rule_eval`：按目标 product token 与路径求值，记录命中的规则原文；更具体的 `Allow` 优先命中时不得判为 disallow。
3. `http_status`：以探测代理的**完整 user-agent 字符串**（取自 taxonomy，不得只写裸 token）实测，记录状态码、最终 URL 与重定向链。
4. `waf_probe`：识别 CDN/WAF 对 AI 代理的拒绝（401/403/429/451/503）、验证码页或空响应，并记录是否可复现。
5. `render_snapshot`：判断正文/关键链接是否必须执行 JavaScript 才能取得；若存在服务端渲染等价物则不得判为阻断。
6. `indexability_control`：记录 `noindex`、`X-Robots-Tag` 等控制事实（**只记录事实**，最终资格归 08）。
7. `canonical_check`：记录 canonical 指向与自有域名的一致性；跨域 canonical 只作事实记录。

**probe 合法性**：`robots_only_token`（例如 `google_extended`）只允许规则求值类 probe；对它执行 `http_status` / `waf_probe` / `render_snapshot` 属于分类错误，结果无效。合法的 probe 类型矩阵见 `GEO_CRAWLER_TAXONOMY.yaml` 的 `probe_validity`。

【重要规则】
1. **未实测不得判定。** 任一必需 probe 未取得 direct 证据时，该 (url, agent) 结论只能是 `evidence_gap`，不得写 `blocked` 或 `eligible`。
2. **blocked 必须给出命中片段。** robots 行原文、响应头或状态码，缺一不可；只有结论没有原始片段的阻断视为无效输出。
3. **不得外推。** 结论只对已探测的 user-agent、control scope 与已探测时间成立；不得声称“所有 AI 系统都会/不会看到”。
4. **不得跨控制面推断。** `GPTBot` 的状态不得用于推断 `OAI-SearchBot`；训练面与检索面必须各有自己的 probe 与 verdict。
5. **不得跨层主张。** eligible 不得被表述为“会被引用”，也不得被表述为引用概率提升。
6. **缺失 ≠ 阻断。** 探测失败（超时、无法连接、需要凭据）属于证据缺口，不是阻断。
7. **robots_controllable=false 的 agent**（用户触发取回）不得用 robots Disallow 判为阻断，只能报告其 robots 可控性事实。
8. **用途控制只记录事实。** `google_extended` 这类 token 的条目使用 `control_recorded` 与 `geo.discovery.control_recorded`，不得写成访问状态。
9. 使用第三方数据代替自测时，`evidence.level` 必须标为 `proxy` 并说明替代关系。
10. 影响面估计必须注明方法；样本外的数字标记为估计值，不得使用精确口径。

【输出格式】
1. 探测条件声明：探测时间、探测方法、robots 获取方式、每个 agent 的完整 user-agent 字符串、control scope、未声明时使用的默认集合、taxonomy 版本与 last_verified 日期。
2. Discoverability Matrix：URL | control_ref | control_scope | verdict（eligible / eligible_with_conditions / blocked_full / blocked_partial / evidence_gap / control_recorded）| 触发 probe | 命中片段 | Evidence ID。
3. 阻断发现表：机制 | 命中片段 | 可复现性 | 影响 URL 样本 | 估计范围（注明方法）| SEO 影响假设与不确定性。
4. 用途控制记录表（无独立 HTTP 身份）：product token | 取值 | 命中片段 | 约束的用途 | 明确不影响的行为。
5. 证据缺口表：缺失 probe 类型 | 原因 | 对结论的影响 | 复核步骤。
6. 控制面分离检查：training 与 search_index 各自的结论并列呈现，并说明二者互不蕴含。
7. SEO Handoff 事实：需要 `08` 最终 indexability/canonical 判断的事实；需要 `09` 渲染判断的事实。
8. 验证契约（遵循 `domain_services/SC12_统一验证契约.md`）：修复后如何用同一探测方法复核，验收标准与回滚条件。
9. Limitations：本模块不能主张的结论清单。

【明确不支持的主张】
- 不得声称“AI 可发现即会被引用”。
- 不得声称某次阻断造成多少引用或流量损失。
- 不得在无官方文档证据时断言某 AI 系统必然遵循或不遵循某条 robots 规则。
- 不得把 `Google-Extended` 的 Disallow 表述为阻止 Googlebot 抓取、索引或影响排名。
- 不得把“阻止训练抓取”与“从生成式答案中消失”写成同一条结论。
- 不得对 robots-only product token 声称任何 HTTP 状态或访问状态。
- 不得输出任何单一 GEO 分数。
