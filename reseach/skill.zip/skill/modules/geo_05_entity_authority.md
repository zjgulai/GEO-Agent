# GEO-05 实体、权威与来源可信度诊断（Entity, Authority & Source Trustworthiness）

**层**：L4_diagnosis | **capability_domain**：`geo_entity_authority` | **Owner**：`geo_05`
**规则 SSOT**：[GEO_05_ENTITY_AUTHORITY_TAXONOMY.yaml](../geo/GEO_05_ENTITY_AUTHORITY_TAXONOMY.yaml)（failure mode、12 维度、证据类型学、置信度、handoff map）
**契约 SSOT**：[GEO_05_DIAGNOSIS.yaml](../geo/GEO_05_DIAGNOSIS.yaml)（输入、输出、signal、handoff 边界）
**作业方法**：[GEO_05_DIAGNOSTIC_METHOD.md](../geo/GEO_05_DIAGNOSTIC_METHOD.md)（怎么诊断）
**结构定义**：`geo/schemas/geo_entity_authority_schema.json`、`geo/schemas/geo_entity_authority_diagnosis_schema.json`

本文件只承载专业作业指导。signal、KPI、handoff 边界与 failure mode 定义**不在此重复**，一律以 SSOT 为准（见 `GEO_SIGNAL_REGISTRY.yaml` 的 `no_pattern_expansion` 规则）。

---

## 1. 什么时候用

- GEO-04 诊断出 `ENTITY_AMBIGUOUS`、`AUTHORITY_GAP`、`EXTERNAL_CORROBORATION_GAP`、`COMPETITOR_SOURCE_SUPERIOR`，需要进一步解释
- 询问 AI 是否能稳定识别品牌 / 公司 / 产品 / 作者 / 组织实体，是否被同名混淆
- 询问品牌—产品—组织之间的关系是否清楚
- 询问为什么竞争来源在 AI 眼里更权威、更可信
- 询问某条 claim 是否有一手证据、第三方印证、独立来源支持
- 询问是否形成持续、稳定的主题专业权威

**不适用**：citation 观测与 KPI（GEO-03）、citation failure 归因（GEO-04）、AI 代理可访问性（GEO-01）、
prompt 词表（GEO-02）、Schema 设计（11）、内容方案（04）、外链与数字公关（18）、测量设计（GEO-06）。

## 2. 认识论边界（必须先读）

GEO-05 只做**诊断假设**。它回答"在当前证据下最可能的实体/权威解释"，而不是"补齐某资产一定会提升引用"。

**三类证据必须分开对待，这是本模块最容易出错的地方：**

| 证据类别 | 定义 | 计入印证 | 计入一手证据 | confidence 影响 |
|---|---|---|---|---|
| `self_claim` | 目标方自己对自己的陈述（官网、官方账号、自出版物料） | ✗ | ✗ | 只有它时上限 `low` |
| `first_party_evidence` | 目标方产生但**可被外部核查**的原始材料（数据集、研究、方法、专利、披露） | ✗ | ✓ | 可支撑"原始出处" |
| `independent_third_party_evidence` | 与目标方无控制关系、且不转述其自述的独立来源 | ✓ | ✗ | 支撑权威与印证结论 |

**明确禁止的推理（违反即视为无效输出）：**

- 用 backlink 数量、Domain Authority、DR/UR、域名权重或任何单一 SEO 指标代表 GEO authority
- 因为有 Schema、Wikipedia 页面或媒体报道，就直接推出"高权威"
- 把 `self_claim` 当作一手证据或第三方印证
- 把转述目标方自述的第三方内容、或与目标方有利益关系（付费/代理/关联/内容互换）的来源计为独立印证
- 把多个引用同一份自述的来源算作多个印证单元（只能算一个）
- 跨 engine / surface / market / locale 合并实体或权威结论
- 把"实体存在"等同于"实体被稳定识别"；把"实体未被识别"等同于"品牌不存在"
- 把"缺少第三方印证"等同于"内容不可信"
- 输出实体权威总分或把多维度合并为单一分数
- 在未检索 counterevidence 时给 `high` confidence

## 3. 十二个诊断维度

维度定义在 taxonomy 的 `diagnostic_dimensions`，此处只给**作业要点**。每次诊断 12 个维度必须各出现一次，状态为 `comparable` 或 `not_comparable`。

| # | 维度 | 作业要点 |
|---|---|---|
| 1 | `entity_clarity` | 实体指代是否明确、有无同名竞争、有无消歧线索。同名冲突必须给实际观察证据，不能凭名字常见就判歧义 |
| 2 | `alias_consistency` | 实际出现的别名集合及其来源类型。判"冲突"前先确认这些写法**不能**归并为同一实体 |
| 3 | `relationship_clarity` | 品牌—产品—组织的归属陈述是否一致。只有 `self_claim` 支持的关系标 `declared`，不得当已证实 |
| 4 | `author_institution_verifiability` | 作者是否具名、机构归属是否可独立核查。匿名 ≠ 低质量 |
| 5 | `first_party_source_strength` | 关键 claim 的原始出处归属：原始数据/研究 vs 二手汇编 vs 纯转述 |
| 6 | `original_research_assets` | 清点**观测中实际出现**的原创数据集、方法、可复现材料及其可核查程度。不得用内容长度或发布频率代替 |
| 7 | `claim_verifiability` | 逐条 claim 判定证据类别与可核查性。无出处主张与可追溯主张必须分开 |
| 8 | `third_party_corroboration` | 只统计**独立**第三方来源。利息相关方与同源转述计入 `limitations`，不计入印证 |
| 9 | `external_source_quality` | 按来源类型与实际相关性逐条评估。禁止用来源数量、域名权重或其链接属性作质量代理 |
| 10 | `topic_coverage_depth` | 覆盖深度 vs 广度必须分开记录。广度本身不是权威 |
| 11 | `source_independence` | 来源之间是否存在利益关系、同源转述、共引一份自述 |
| 12 | `freshness_and_continuity` | 持续更新 vs 单次发布后停滞。不得把更新频率高等同于权威高 |

## 4. 作业流程（7 步）

1. **确认入口合法**：本诊断来自 GEO-04 的哪个 failure mode（`geo04_entry`），或来自显式实体/权威问题。
   来自 GEO-04 时，`engine_id` / `surface_id` / `prompt_id` 必须与父诊断完全一致。
2. **锁定作用域**：`engine_id::surface_id::market::locale`。四者任一不同即视为不同作用域，必须分别结论。
3. **建立 Entity / Authority Evidence Object**：为 target 与每个竞争实体各建一个 profile，填 `canonical_name`、
   `aliases`、`relationship_refs`、三类证据、`source_independence`、`freshness`。
4. **逐条 claim 分类**：把每条关键 claim 归入 `self_claim` / `first_party_evidence` /
   `independent_third_party_evidence` / `none`。**同一证据不得出现在两个类别里**。
5. **计算独立印证单元**：排除利益相关方与同源转述，得到 `independent_unit_count`。
   多个来源共引一份自述时只算一个单元，并记入 `shared_origin_refs`。
6. **逐维度比较并定 failure mode**：按 `required_dimensions` 与 `requires_favors` 定向要求选定 mode；
   同时检查 `cannot_be_primary_when` 未被触发。
7. **定 confidence 与 handoff**：confidence 只由证据状态导出，**不由 failure mode 导出**；
   按 handoff_map 给出 `recommended_next_owner`，并写入 `trace_writeback`。

## 5. 输出要求

- 每条 diagnosis 含：12 维比较、`evidence_class_split`（三类证据分开列）、`primary_failure_mode`、
  `confidence`、`evidence_refs`、`counterevidence_refs`、`compared_entities`、`reasoning_summary`、
  `recommended_next_owner`、`trace_writeback`
- `AUTHORITY_SIGNAL_CONFLICT` 必须同时列出 `strength_dimensions` 与 `weakness_dimensions` 及 `conflict_pairs`
- `UNRESOLVED` 必须给 `unresolved_gaps`（缺什么、怎么补）
- 证据不足时输出 `low confidence` 或 `unresolved`，**不得**强行归类到某个 failure mode

## 6. 反模板要求

同样输入必须得到同样结论；**改变证据必须改变结论或 confidence**。
若两次运行 evidence 不同而 diagnosis 完全不变，视为模板化输出，由 counterfactual 回归用例检出。

## 7. handoff 边界

GEO-05 不重复实现已有专业域的能力：

| root cause | Owner | 边界 |
|---|---|---|
| 实体命名、别名归一、结构化数据设计 | `11` | Schema 只作一致性事实，**不得**作为权威证据 |
| 消歧页面、作者页、机构页内容结构 | `04` | GEO-05 只给诊断，不产出内容方案 |
| 独立第三方来源建设、数字公关 | `18` | 不得用 backlink 数量代表权威 |
| 竞品一手数据整体更强 | `03` | 竞争与内容差距判断归 03 |
| 时效衰退与资产更新 | `17` | 更新与否由 17 决定 |
| 观测缺口 | `geo_03` | GEO-05 不补数 |
| citation failure 归因 | `geo_04` | GEO-05 只消费其 handoff |
| 测量设计与跨市场可比性 | `geo_06`（已实现） | 交 GEO-06；GEO-05 不做测量 |

## 8. canonical trace 回写

GEO-05 复用 `canonical_v1_5` profile，**不新增对象类型**：

- **Evidence**：每条 diagnosis 至少一个，`level` 沿用既有枚举 `direct|derived|proxy|inference|unknown`
- **Decision**：`source_module=geo_05`，`capability_domain=geo_entity_authority`，
  `decision_id` 必须等于 `diagnosis_id`
- **Handoff**：`recommended_next_owner` 非 `geo_05` 时产生，`from=geo_05`；
  目标为已实现的 `geo_06` 时，Owner 可用则 `status=open`；实际不可用则 `status=deferred`，GEO-05 不接管最终测量判断。原生 validator 的 `runtime_context` 使用既有 `execution_context.availability`；不传时仅按包内已注册模块均可用做产物校验，不声称验证了真实运行可用性。

证据 id 约定：`g05e_<diagnosis_id>_<dimension>`。

## 9. 与 GEO-04 的分工

| 问题 | 归属 |
|---|---|
| 为什么没被引用 / 竞品为什么被引用 | GEO-04（9 维 source comparison） |
| AI 是否能稳定识别我们的实体 | **GEO-05** |
| 实体关系是否清楚 | **GEO-05** |
| 为什么竞品在 AI 眼里更权威（实体/权威层） | **GEO-05** |
| claim 是否有一手证据与独立印证 | **GEO-05** |
| 是否形成持续主题专业权威 | **GEO-05** |

GEO-05 是 GEO-04 的下游：它**消费** GEO-04 的 handoff 与已冻结的观测/画像，**不重算**可见性，
也**不重判** citation failure mode。
