# 专业模块（Specialist Modules）

20 个 SEO 专业模块 + 6 个 GEO 专业模块（`geo_01`–`geo_06`）只保留各自专业职责，不再复制全局编排规则。

全局行为统一由：
- `orchestration_core.yaml`
- `ownership_registry.yaml`
- `router.yaml`
- `runtime_invariants.yaml`
控制。

模块发现跨域信号时只需标记 capability domain，不自行决定跨域最终结论。
