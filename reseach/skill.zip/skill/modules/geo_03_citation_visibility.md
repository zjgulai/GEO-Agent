geo_03_citation_visibility — GEO-03｜Answer & Citation Visibility（答案与引用可见性）

【Phase 1 模块边界】
- Module ID：`geo_03`（人类别名 GEO-03）
- 专业职责：生成式搜索可见性观测层（observation layer）
- Layer：`L3_observed_citation`
- Capability domain：`geo_citation_visibility`（Owner 为 `geo_03`）
- Contract：`geo/GEO_MODULE_CONTRACT.yaml` 中 `module_id: geo_03` 条目是本模块 scope / inputs / outputs / signals / handoff / evidence / guardrail 的 Single Source of Truth。
- Signal 触发条件与可主张边界见 `geo/GEO_SIGNAL_REGISTRY.yaml`；KPI 定义与可追溯要求见 `geo/GEO_METRIC_CONTRACT.yaml`。
- 全局编排规则继承 `minimal_execution_protocol.yaml` 与 `runtime_invariants.yaml`；本模块不得重定义。
- 证据对象结构复用 `domain_services/SC02_证据对象标准化.md` 的 provenance 要求（来源、时间、范围、可复核位置），并新增 raw response 作为证据来源类型。

【核心纪律：evidence-first，可追溯，可重复验证】
**Observed Citation ≠ 优化效果。** 本模块只记录“在某引擎/模型、某时刻、某 prompt 下实际发生了什么”。
**任何汇总统计都必须能逐条回到原始响应。不允许只有分数而没有原始证据。**

【与 SEO Core 及 GEO-01/02 的边界】
- Prompt universe 由 `geo_02` 提供；本模块是**消费方**，运行期不得改写 prompt、维度或别名表。
- 自有 URL 的 indexability / canonical 现状：归 `08`。
- 被引用 URL 的站内可达性：归 `14`。内容衰退：归 `17`。竞品内容差距：归 `03`。内容结构：归 `04`。
- `geo_01` 的 discoverability 状态与本模块的观测结论**分别报告**，不得合并为单一结论。

【工作流定位】
- 能力定位：逐 prompt 执行、原始响应留档、品牌/引用抽取、KPI 计算。
- 上游输入：frozen prompt universe、引擎/模型矩阵、raw response 存放位置、自有与竞品域名、观测时间窗。
- 本 Prompt 输出：observation records、KPI report、分组可见性事实、失败观测台账。
- 下游衔接：`03`、`04`、`08`、`14`、`17`。

【输入】
Prompt Universe：[universe_id + universe_version + metadata_hash，必须为 frozen]
引擎/模型矩阵：[provider / product / model / mode；未覆盖的引擎必须在报告中显式列出]
Raw response 存放：[可复核 locator + content_sha256；禁止只存摘要文本]
自有域名 / 竞品域名：[来自 universe 的实体定义]
观测时间窗：[window_start / window_end；单次观测不得作为比率]

【每条 observation 的最低字段（全部必填，缺失即无效）】
1. `prompt_id`
2. `engine`：`provider` / `product` / `model` / `mode`
3. `executed_at`（执行时间戳）
4. `raw_response_ref`：`locator` + `content_sha256`（原始响应引用）
5. `brand_mention`：`present` + `mentions[]`（`entity_id` / `matched_alias` / `match_method` / `snippet`）
6. 竞品提及：同一 `mentions[]` 中以 `entity_id` 区分，竞品实体 id 来自 universe
7. `own_domain_citation`：布尔值，必须与 `citations[]` 中的 `ownership: own` 一致
8. `citations[]`：`citation_url`（保留原始字符串） / `cited_domain` / `ownership`（own / competitor / third_party / unknown）
9. `execution_status`：`ok` 或失败类别，失败时必须给 `error`

【执行规则】
1. **原始响应必须先落盘再统计。** 记录写入顺序必须是：保存 raw response → 计算 `content_sha256` → 写 observation → 再计算 KPI。
2. **失败观测与成功观测严格分离。** `execution_status != ok` 的记录：
   - 不得计入任何 KPI 的分子或分母；
   - 不得携带 `brand_mention` / `citations` / `own_domain_citation` 结论（缺失不等于 absent）；
   - 必须进入 `error_ledger` 并报 `geo.observation.error`。
3. **缺失 ≠ 0。** 无观测或无 raw response 时，指标状态必须是 `unavailable` 并给出原因，**禁止填 0**。
4. **单次观测不是比率。** 样本量为 1 时只能陈述单次观测事实，不得输出比率结论。
5. **小样本必须标注。** 分组 `sample_size < 5` 时状态为 `small_sample`，不得作为结论。
6. **引擎必须分列。** 禁止跨引擎合并为单一分数或单一可见性数字。
7. **别名归一化只在 universe 声明的表内进行。** 运行期不得临时新增竞品别名。
8. **历史观测不可改写或删除。** 修正必须新增记录，并用 `supersedes` 指向被取代的 observation_id。
9. **提及 ≠ 引用。** brand mention 与 own-domain citation 必须分别统计、分别报告。
10. **引用缺口必须双侧举证。** 报 `geo.citation.gap` 时必须同时给出竞品侧证据与自有侧缺失证据。

【KPI 计算（第一版只保留 6 个 canonical KPI）】
| KPI | 公式 | 说明 |
|---|---|---|
| Prompt Coverage | distinct(prompt_id with status=ok) / universe active prompt 数 | 覆盖高不代表被引用 |
| Brand Mention Rate | distinct(obs with brand_mention=true) / distinct(obs with status=ok) | 不得推出 citation |
| Own-domain Citation Rate | distinct(obs with own_domain_citation=true) / distinct(obs with status=ok) | 不得推出排名/流量 |
| Citation Share | own citation 行数 / 已解析 cited_domain 的 citation 行数 | 必须按引擎分列 |
| Competitor Mention Share | 竞品实体 mention 数 / universe 实体 mention 数 | 不得解读为市场份额 |
| Intent-level Visibility | 按 `metadata.intent` 分组，复用自有实体 brand_mention_rate 与 own_domain_citation_rate | 每组必须给 sample_size |

自 1.6.0 起 `brand_mention_rate` 只计有效观测中解析到 own_entity 的提及，按 observation_id 去重；`brand_mention.present` 在仅提竞品时也可能为真，不能替代自有实体解析。竞品提及份额保留自身完整 evidence 集合，不限于自有提及的观测。旧版数值的迁移边界见 [迁移说明](../MIGRATION_1.6.0.md)。

每个 KPI 必须随附：`observation_ids`、`sample_size`、`engine_scope`、`model_scope`、`universe_version`、`window_start`/`window_end`、`error_count`。
任一字段缺失，该 KPI 视为**无效输出**。

【输出格式】
1. 观测条件声明：universe 版本、引擎/模型矩阵、观测窗口、raw response 存放位置与哈希算法。
2. Observation Ledger：observation_id | prompt_id | engine/model | executed_at | execution_status | raw_response_ref | brand_mention | own_domain_citation | citation 数 | Evidence ID。
3. KPI Report：6 个 KPI + 每个 KPI 的 traceability block（对应 `geo/schemas/geo_kpi_report_schema.json`）。
4. 分组可见性事实：按 intent / persona / journey stage / topic 分组，逐组给 sample_size 与分组指标。
5. Citation Share 明细：被引用域名排行（自有 / 竞品 / 第三方分列），每个域名给出来源 observation_id。
6. Error Ledger：失败类别 | 次数 | 涉及引擎/模型 | 时间窗 | 是否可重试。
7. GEO Handoff 事实：交给 `03` / `04` / `08` / `14` / `17` 的观测事实与 Handoff。
8. Limitations 与 unsupported claims 清单。

【明确不支持的主张】
- 不得声称某次观测结果代表所有用户或所有时间。
- 不得声称引用或提及等于流量、排名、转化或收入。
- 不得声称某项优化一定提高 AI citation（除非有前后对照观测，且报告了混杂因素）。
- 不得把 provider 失败解释为品牌不可见，也不得把失败观测计入任何比率。
- 不得输出单一 0–100 GEO Score，也不得输出跨引擎加权综合分。
