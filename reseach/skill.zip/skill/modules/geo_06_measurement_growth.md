# GEO-06 度量、增长与实验闭环（Measurement, Growth & Experiment Loop）

**层**：L4_diagnosis | **capability_domain**：`geo_measurement` | **Owner**：`geo_06`
**规则 SSOT**：[GEO_06_MEASUREMENT_TAXONOMY.yaml](../geo/GEO_06_MEASUREMENT_TAXONOMY.yaml)（可比性、变化判断、归因边界、实验契约、优先级维度、商业价值口径）
**契约 SSOT**：[GEO_06_DIAGNOSIS.yaml](../geo/GEO_06_DIAGNOSIS.yaml)
**作业方法**：[GEO_06_MEASUREMENT_METHOD.md](../geo/GEO_06_MEASUREMENT_METHOD.md)
**结构定义**：`geo/schemas/geo_measurement_schema.json`、`geo/schemas/geo_intervention_priority_schema.json`
**KPI 口径**：`geo/GEO_METRIC_CONTRACT.yaml`（6 个 canonical KPI 的 SSOT，本模块不得重定义）

本文件只承载专业作业指导。signal、KPI 口径与 handoff 边界**不在此重复**（见 `GEO_SIGNAL_REGISTRY.yaml` 的 `no_pattern_expansion` 规则）。

---

## 1. 什么时候用

- GEO-04 / GEO-05 已给出诊断，需要验证优化后**是否真的有效**
- 需要设计 GEO 干预实验（对照组、主指标、成功判据、混淆因素）
- 需要判断某项 GEO 投入**是否值得继续**
- 需要按 engine / surface / market / locale / intent / topic 做**长期趋势监测**
- 需要把 GEO 可见性变化连接到 **AI referral 或商业价值**

**不适用**：观测采集（GEO-03）、citation 归因（GEO-04）、实体/权威判定（GEO-05）、可访问性（GEO-01）、词表建设（GEO-02）、内容方案（04）、来源建设（18）、统计功效与预算排序（19）。

## 2. 闭环

```
观察 → 诊断 → 干预 → 重新观测 → 对比 → 判断 → 后续行动
 ↑                                              │
 └────────────── 固定 Prompt Universe ───────────┘
```

GEO-06 负责**对比 → 判断 → 后续行动**三段，以及"重新观测"的窗口设计。
它**不负责**观察本身（GEO-03），**不负责**诊断（GEO-04/05）。

## 3. 基线与复测

**两个窗口只有完全同构时才可比较。** 任一维度不同即判 `not_comparable`：

| 维度 | 要求 |
|---|---|
| `universe_id` | 必须相同 |
| `universe_version` | **必须相同**。版本升级后新旧窗口不是同一测量仪器，只能分别报告 |
| `engine_id` | 必须相同 |
| `surface_id` / `surface_type` | **必须相同**。API surface 与 consumer surface 不是同一链路 |
| `market` | 必须相同 |
| `locale` | 必须相同 |
| `prompt_set` | 实际取得有效观测的 prompt 集合漂移不得超过 `max_prompt_set_drift`（0.2） |

**窗口规则**：baseline 必须早于 post 且不重叠；每窗口至少 `min_observations_per_window`（5）条 `execution_status=ok` 观测；失败观测单列，不参与任何比率。

## 4. 核心指标

**前 6 个是冻结的 canonical KPI，口径见 `GEO_METRIC_CONTRACT.yaml`，本模块不得重定义**：

`prompt_coverage` · `brand_mention_rate` · `own_domain_citation_rate` · `citation_share` · `competitor_mention_share` · `intent_level_visibility`

1.6.0 的 canonical `brand_mention_rate` 使用 own_entity 解析与有效 observation 去重；旧 `own_brand_mention_rate` 保留为兼容名称，复用同一计算，不能同时作为两个独立信号。旧 1.5.0 的 present 历史数值不可直接与新口径比较，见 [迁移说明](../MIGRATION_1.6.0.md)。

**GEO-06 新增 3 个增长分析指标**（口径在 taxonomy 的 `metrics.added_for_growth`）：

| 指标 | 用途 |
|---|---|
| `citation_gap_closed_rate` | baseline 窗口被判 citation_gap 的 prompt，在 post 窗口自有侧出现的比例。直接回答"原本漏掉的 prompt 是否补上" |
| `citation_share_delta_vs_competitor` | 自有份额变化减去竞品份额变化。排除"引用池整体变大"造成的假改善 |
| `visibility_stability` | 同一 prompt 多次观测结论一致的比例。区分真实提升与单次波动 |

**护栏指标**：`error_observation_count`、`competitor_mention_share`、`own_domain_citation_rate`、`visibility_stability`。

> 指标值由校验器**重算**（复用 `citation_visibility_metrics`），record 不能自报一套算法。

## 5. 变化判断

只有四个取值，判定顺序固定：**先判不可比 → 再判未达阈值 → 最后按方向判**。

| 取值 | 条件 |
|---|---|
| `inconclusive` | 可比性不成立 / 任一窗口样本不足 / 观测失败过多 / 稳定度过低 / 指标 unavailable |
| `no_material_change` | 可比且样本达标，但主指标变化幅度低于 materiality 阈值（0.05） |
| `improved` | 可比、样本达标、主指标正向变化达到阈值、护栏未触发降级 |
| `declined` | 与 improved 对称，方向为负 |

**硬性要求**：

- 每个窗口有效观测 < 5 时**不得**判 improved / declined
- 只由**单条**观测支撑的指标不得用于 improved / declined
- materiality 阈值是**工程约定，不是统计显著性检验**，不得如此表述
- `inconclusive` 必须给 `unresolved_gaps`，且 confidence 只能是 `unresolved` 或 `low`

## 6. 实验契约

九项必填，缺一不可：

`hypothesis` · `treatment` · `control` · `primary_metric` · `guardrail_metric` · `baseline_window` · `post_window` · `success_criterion` · `confounders` · `evidence_strength`

| 设计类型 | 归因上限 | 最低要求 |
|---|---|---|
| `controlled_comparison` | `experimental_evidence` | 2 个 arm，每 arm ≥ 3 条观测 |
| `before_after_single_group` | **`association`** | 无对照组 |
| `interrupted_time_series` | `experimental_evidence` | ≥ 4 个窗口 |

**支持的干预类型**（每种绑定上游 failure mode）：

| 干预 | 来源 | 建议主指标 |
|---|---|---|
| `add_first_party_data` | GEO-05 `FIRST_PARTY_EVIDENCE_WEAK` | `own_domain_citation_rate` |
| `add_third_party_corroboration` | GEO-05 `ORIGINAL_RESEARCH_WITHOUT_CORROBORATION` | `brand_mention_rate` |
| `fix_entity_relationship` | GEO-05 `RELATIONSHIP_CONFLICT` | `brand_mention_rate` |
| `resolve_entity_ambiguity` | GEO-05 `ENTITY_AMBIGUOUS` | `brand_mention_rate` |
| `close_answer_gap` | GEO-04 `ANSWER_GAP` | `citation_gap_closed_rate` |
| `improve_extractability` | GEO-04 `EXTRACTABILITY_WEAK` | `own_domain_citation_rate` |
| `refresh_stale_content` | GEO-04 `FRESHNESS_GAP` | `own_domain_citation_rate` |
| `strengthen_primary_source` | GEO-04 `EVIDENCE_WEAK` | `citation_share` |

**混淆因素词表**：`engine_model_update`、`engine_ranking_change`、`seasonal_demand_shift`、`competitor_launch`、`concurrent_site_change`、`measurement_instrument_change`、`universe_version_change`、`media_event`、`unrelated_campaign`。每项必须声明 `controlled` / `observed_not_controlled` / `not_applicable` / `unknown`。

## 7. 归因边界

四级阶梯，**只能由设计决定，不由指标变化幅度决定**：

| 层级 | 需要什么 | 允许的表述 |
|---|---|---|
| `observation_change` | 两个可比窗口 | 指标从 A 变为 B |
| `association` | + 干预时间线 | 该变化在干预之后出现，可能相关 |
| `experimental_evidence` | + 对照组 + 每 arm ≥ 3 条 | 处理组相对对照组出现方向一致的差异 |
| `causal_claim` | + confounders 已处理 + 跨 ≥ 2 窗口重复 | 在该范围内该干预是该变化的原因 |

**无对照组时归因上限为 `association`，confidence 上限为 `low`。**

> 没有合理实验设计时，**不允许**声称"某项优化导致 Citation Rate 提升"。

## 8. 增长机会优先级

把 GEO-04 / GEO-05 的诊断转成 intervention，每个维度给**离散等级**，按**字典序**排序：

```
evidence_strength(experimental > observational > inferred > none)
  → expected_impact(high > medium > low > unknown)
    → measurement_feasibility(controlled_possible > before_after_only > not_measurable)
      → implementation_cost(low < medium < high)
```

七个维度：`expected_impact` · `evidence_strength` · `implementation_cost` · `urgency` · `dependency` · `reversibility` · `measurement_feasibility`

**明确禁止**：加权求和、单一 GEO 优先级分数。schema 中 `weighted_total` 刻意固定为 `null`。

`measurement_feasibility = not_measurable` 时**不得承诺**可验证效果。

## 9. 商业价值

**三态输出**：

| 模式 | 条件 |
|---|---|
| `point_estimate` | 五项输入齐备（AI referral、辅助转化、转化率、收入/线索价值、成本），且 referral 可归因到具体 engine/surface |
| `scenario_range` | 缺少一项或多项输入；只能给保守/中性/乐观区间并列出缺失输入 |
| `not_estimable` | 缺少 AI referral 或收入/线索价值 |

**禁止**：把 citation 变化直接换算为收入；用外部行业均值代替本项目数据；输出未经引用的 ROI 百分比；把国内与海外商业价值合并。

## 10. 长期监测

固定 Prompt Universe 版本，按六个维度**分别切片**输出：

`engine_id` · `surface_id` · `market` · `locale` · `intent` · `topic`

**禁止合并**：

- 国内 AI 引擎与海外 AI 引擎**不得**合并为一个总分
- consumer surface 与 API surface **不得**合并为一个总分
- 不同 market 或 locale **不得**合并为一个总分

少于两个可比窗口时**只能输出当前状态，不得输出趋势**。

## 11. 输出要求

每条 measurement 必须包含：两窗口定义、主指标与护栏指标（含 numerator/denominator/sample_size）、可比性逐维度判定、实验设计、`change_classification`、`attribution_level`、`confidence`、`business_impact`、`recommended_action`、`trace_writeback`。

## 12. 反模板要求

同样输入必须得到同样结论；**改变 evidence / control / baseline 必须改变 change_classification、confidence 或 business conclusion**。由 counterfactual 回归用例 `geo06_counterfactual_*` 检出。

## 13. handoff 边界

| root cause | Owner | 边界 |
|---|---|---|
| 观测缺口、失败观测 | `geo_03` | GEO-06 不补数 |
| citation failure 归因 | `geo_04` | 只消费其诊断 |
| 实体与权威判定 | `geo_05` | 只消费其干预建议 |
| 统计功效与显著性 | `19` | GEO-06 只产出 GEO 侧测量结论 |
| 跨项目预算排序 | `19`（portfolio） | 归 19 |
| 内容侧干预落地 | `04` | 归 04 |
| 第三方来源建设 | `18` | 归 18 |
| 结构化数据与实体标记 | `11` | 归 11 |
| 月度复盘流程 | `20` | GEO-06 输出作为输入 |

## 14. canonical trace 回写

复用 `canonical_v1_5`，**不新增对象类型**：

- **Evidence**：每条 measurement 至少一个，`level` 沿用 `direct|derived|proxy|inference|unknown`
- **Decision**：`source_module=geo_06`，`capability_domain=geo_measurement`，`decision_id == measurement_id`
- **Handoff**：`recommended_action.next_owner` 非 `geo_06` 时产生，`from=geo_06`
- `change_classification=inconclusive` 时**不得**产生 causal Claim

证据 id 约定：`g06e_<measurement_id>_<metric_id>`。
