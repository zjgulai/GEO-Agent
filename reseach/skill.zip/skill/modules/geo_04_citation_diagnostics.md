geo_04_citation_diagnostics — GEO-04｜Grounding & Citation Diagnostics（引用归因诊断）

【Phase 1 模块边界】
- Module ID：`geo_04`（人类别名 GEO-04）
- 专业职责：解释"为什么目标品牌/页面没有被引用，而竞争来源被引用"
- Layer：`L4_diagnosis`
- Capability domain：`geo_citation_diagnostics`（Owner 为 `geo_04`）
- Contract：`geo/GEO_04_DIAGNOSIS.yaml` 与 `geo/GEO_MODULE_CONTRACT.yaml` 中 `module_id: geo_04` 条目是本模块 scope / inputs / outputs / signals / handoff / evidence / guardrail 的 Single Source of Truth；本文件不重复定义。
- Taxonomy：`geo/GEO_04_CITATION_FAILURE_TAXONOMY.yaml`（failure mode、必需维度、置信度阈值、handoff_map）—— 本文件不复制 failure mode 定义。
- Method：`geo/GEO_04_DIAGNOSTIC_METHOD.md`（9 维比较口径与 7 步流程）。
- Signal：`geo/GEO_SIGNAL_REGISTRY.yaml` 的 `geo.diagnosis.*`。
- 全局路由、证据校准、Owner/Handoff、Dedup、Dependency、Context 与 Trace 遵循 `minimal_execution_protocol.yaml` 与 `runtime_invariants.yaml`。

【核心定位】
GEO-01～03 解决"发生了什么"；GEO-04 解决"为什么"。
**输出的是诊断假设，不是因果证明。** 证据不足时输出 `low confidence` 或 `UNRESOLVED`，不强行分类。

【先决条件：citation failure 成立】
诊断之前必须确认三件事同时成立：
1. 观测 `execution_status = ok`；
2. 自有侧缺失（brand mention 缺失 且/或 own-domain citation 缺失）；
3. 至少一个竞争来源出现。
不满足时不得诊断为 citation failure。观测执行失败是**观测缺口**，回到 GEO-03。

【优先动作：target vs cited competitor 的 9 维来源比较】
必须逐维度比较并给出 `comparable` / `not_comparable`（含原因）：

| 维度 | 比较内容 |
|---|---|
| `intent_alignment` | 页面职责与题型是否对应 prompt 意图 |
| `answer_completeness` | 逐要素列目标缺失项与竞争覆盖项 |
| `evidence_provenance` | 一手数据 / 公开方法 / 可追溯来源数量 |
| `freshness` | published / updated 日期或等效时效信号 |
| `entity_clarity` | 实体命名一致性与同名冲突 |
| `extractability` | 段落自足性、结构信号、渲染依赖 |
| `primary_source_strength` | 原始出处 / 二手汇编 / 转述 |
| `third_party_corroboration` | 观测中**实际出现**的独立第三方来源数 |
| `topic_authority` | 双方在该主题下的**相对**深度观察 |

比较必须落到结构化的 source profile 上（`geo/schemas/geo_source_profile_schema.json`），不得只写文字判断。

【与 SEO Core / 其他 GEO 模块的边界（禁止重复实现）】
- 可访问性 / crawl-index / robots → `geo_01`（技术处置顺序归 `08`，渲染归 `09`）
- 意图与页面职责冲突 → `15`
- 内容结构、答案要素、可摘录形态 → `04`
- 时效与内容衰退 → `17`（GEO-04 只做诊断，不写更新方案）
- 第三方印证与站外资产 → `18`
- 结构化数据一致性 → `11`（**Schema 只能作一致性事实，不得作为 citation 因果证据**）
- 竞争来源整体更优 → `03`
- 实体与权威深层分析 → `geo_05`（已实现；交接实体与权威判定）
- 观测不足需重跑扩窗 → `geo_06`（已实现；交接测量设计与窗口可比性）
- 观测本身失败或不可追溯 → `geo_03`

【证据规则】
1. 每条 diagnosis 必须绑定一个 `execution_status=ok` 的 observation，并**复用**其 `engine_id` / `surface_id` / `prompt_id`。
2. **保持 surface 隔离**：诊断只能引用同一 `engine_id::surface_id` 的观测与画像。
3. **不同 surface 结论冲突时，不得跨 surface 推因果** —— 分别给出 surface 级结论并记录 `surface_conflict`。
4. 每个 failure mode 必须有 `evidence_refs`；`high` confidence 必须另有 `counterevidence_refs`（已检索到的反证，或"已检索未发现"）。
5. 观测缺 raw response 引用时，confidence 上限为 `low`，且不得给出具体 failure mode。
6. `render_dependency = client_side_only` 时**不得**判 `EXTRACTABILITY_WEAK`，应先交 `09`。
7. `COMPETITOR_SOURCE_SUPERIOR` 需至少 3 个维度竞争方占优，且必须指出目标方至少一个占优或打平维度。
8. 全部维度 `not_comparable`、或缺任一侧画像时，只能 `UNRESOLVED`，并列出补齐所需证据。

【confidence 判定（由证据状态导出，不由 failure mode 类型导出）】
- `high`：必需维度全部 comparable、两侧画像齐备、有 raw response 引用、已给出至少一条 counterevidence
- `medium`：必需维度 comparable 但 counterevidence 不完整，或某非必需维度不可比
- `low`：有关键维度仅部分可比，或一侧画像不完整
- `unresolved`：无任一维度可比，或缺任一侧画像，或观测不可追溯（此时 primary failure mode 必须是 `UNRESOLVED`）

【多因并存】
允许并存多个 failure mode：指定 `primary_failure_mode`，其余进 `secondary_failure_modes`。
primary 必须未触发其 `cannot_be_primary_when`，且 `requires_discovery_reference` 已满足；secondary 也必须有各自证据。

【输出格式】
1. 诊断范围声明：observation_id、prompt_id、engine_id、surface_id、观测通道、执行区域。
2. Citation Outcome：自有侧缺失/存在、竞争侧出现情况、outcome class。
3. Source Comparison Matrix：9 维度 × (target | competitor | status | favors | evidence)。
4. Failure Mode 判定：primary + secondary，逐条附 evidence 与命中的维度。
5. Confidence 与依据：confidence + confidence_basis + 反证检索结果。
6. Compared Sources：目标与全部被引用竞争来源（含是否在观测中被引用）。
7. Reasoning Summary：从证据到结论的推理链，明确标注未解决的空白。
8. Handoff：`recommended_next_owner` + 边界说明 + 交付给该 Owner 所需的最小事实集。
9. Unresolved / 补证清单：缺什么证据、如何补齐、补齐后能区分哪几个候选 failure mode。
10. Surface Conflict（如有）：两个 surface 各自的结论与冲突记录。
11. Limitations 与本模块不支持的主张。

【明确不支持的主张】
- 不得把 Schema / FAQ / llms.txt / 内容长度 / 关键词密度直接当作 citation 因果证据。
- 不得由 API surface 的观测推断 consumer surface 的行为（反之亦然）。
- 不得用单个 prompt 的观测外推到意图、主题或引擎整体。
- 不得声称已证明因果；不得声称"改某处一定会被引用"。
- 不得输出域名权威度评分或任何外部权威指标。
- 不得输出 GEO 总分，或把多条 failure mode 合并成单一结论。
- 不得把"未被引用"等同于"内容质量差"。
