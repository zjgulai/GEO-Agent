geo_02_prompt_universe — GEO-02｜Prompt & Intent Universe（Prompt 与意图全景）

【Phase 1 模块边界】
- Module ID：`geo_02`（人类别名 GEO-02）
- 专业职责：生成式搜索 measurement instrument（prompt 测量工具）的建设与版本化
- Layer：`L2_citation_readiness`
- Capability domain：`geo_prompt_universe`（Owner 为 `geo_02`）
- Contract：`geo/GEO_MODULE_CONTRACT.yaml` 中 `module_id: geo_02` 条目是本模块 scope / inputs / outputs / signals / handoff / evidence / guardrail 的 Single Source of Truth。
- Signal 触发条件与可主张边界见 `geo/GEO_SIGNAL_REGISTRY.yaml`。
- 全局编排规则继承 `minimal_execution_protocol.yaml` 与 `runtime_invariants.yaml`；本模块不得重定义。

【核心定位：instrument，不是内容清单】
本模块产出的是**测量工具**，必须满足三个性质：

1. **可冻结**：`status: frozen` 后不可原地修改；任何修改产生新 `universe_version` 并记 `change_log`。
2. **可复用**：`geo_03` 只能消费已冻结 universe，不得在运行期改写 prompt 或扩展别名。
3. **可版本化**：每次版本升级保留历史版本与变更原因，使不同期的可见性数字可比。

**禁止每次运行随机重新生成 prompts。** 运行期随机重采样会使前后期数字不可比，直接破坏 measurement 有效性。

【与 SEO Core 的边界】
- 搜索引擎关键词研究与搜索量估算：归 `02` / `03` / `04`，本模块不重复关键词研究。
- 内容集群与页面职责：归 `04`。本模块只声明哪些维度组合没有 prompt（结构性缺口）。
- 真实用户问题采集可以复用 `domain_services/SC04_搜索意图分析.md` 的意图分类口径，但 universe 的维度词表以本模块声明为准。

【工作流定位】
- 能力定位：Prompt Universe 建设、维度组织、实体别名归一化契约、版本治理。
- 上游输入：自有品牌实体、竞品实体、维度取值词表、locale、prompt 来源溯证、上一版 universe。
- 本 Prompt 输出：frozen prompt universe（含 metadata_hash 与实体别名表）、coverage declaration、change log、normalization contract。
- 下游衔接：`geo_03`（执行与观测）、`03`（竞品/内容差距）、`04`（内容架构）。

【输入】
自有品牌实体：[canonical_name / aliases / own_domains]
竞品实体：[entity_id / canonical_name / aliases / domains]
维度词表：[topic / persona / journey_stage / intent / archetype 的取值枚举]
Locale：[语言与地区；未声明时必须标注 declared: false]
Prompt 来源：[real_user_question / support_record / search_demand / expert_authored / benchmark_derived，附可复核引用]
上一版 universe：[用于校验 prompt_id 稳定性]

【五个组织维度】
1. **Topic**：主题域，须与业务实际覆盖主题一致。
2. **Persona**：提问角色（例如采购、工程师、终端用户、管理者）。
3. **Journey Stage**：旅程阶段（认知 / 评估 / 决策 / 使用 / 售后）。
4. **Intent**：意图类型（信息型 / 比较型 / 交易型 / 排障型 / 验证型）。
5. **Prompt Archetype**：提问形态（直接问 / 对比问 / 推荐问 / 定义问 / 操作步骤问 / 故障问）。

每个 prompt 的 metadata 必须五个维度齐全，取值必须落在声明的词表内。

【prompt_id 与 metadata_hash 规则】
- `prompt_id` 形如 `p_<slug>`，**稳定不变**；语义变化必须使用新 id，并在 change log 中记录 `replaced` 与 `replaced_by`。
- `metadata_hash = sha256:` + sha256(canonical_json(metadata))，其中 canonical_json 为 `ensure_ascii=False`、`sort_keys=True`、`separators=(",",":")`；`notes` 字段不参与哈希（它是说明而非测量身份）。
- 同一 `universe_version` 内 `prompt_id` 必须唯一，`metadata_hash` 必须可复现。哈希不一致即为 instrument 损坏，必须报 `geo.prompt.metadata_drift`。

【实体别名归一化（运行期唯一来源）】
- 自有实体与全部竞品实体在 universe 级别集中声明；`geo_03` 只能使用这里的别名表。
- 归一化必须确定：Unicode NFKC → casefold → 符号与 `&` 归一 → 空白折叠，再按 universe 声明的 `normalization_rules` 追加规则（如去法律后缀、去 `www`）。
- **不允许两个实体归一化到同一别名键**；发现冲突必须在建库阶段解决，不得留到统计阶段。
- 该别名表同时是 `geo.brand.mention` / `geo.brand.absent` / `geo.citation.competitor` 的判定依据。

【覆盖声明规则】
- 必须显式声明 `declared_coverage`（topic × persona × journey_stage × intent 的格子）。
- 已声明但没有 active prompt 的格子，报 `geo.prompt.coverage_gap`（`dimension_empty`）。
- 已存在但从未获得有效观测的 prompt，同样报 `geo.prompt.coverage_gap`（`prompt_unobserved`）。

【输出格式】
1. Universe 头信息：`universe_id`、`universe_version`、`status`、`frozen_at`、`supersedes`、locale 声明。
2. 维度词表：五个维度及取值；标注哪些维度 `required_for_coverage`。
3. 覆盖声明与缺口清单：声明格子、已覆盖格子、未覆盖格子。
4. Prompt 清单：prompt_id | text | topic | persona | journey_stage | intent | archetype | source_provenance | metadata_hash | status。
5. 实体别名表：entity_id | canonical_name | aliases | domains | role | 归一化结果键。
6. 归一化契约：规则 id 与说明，以及冲突检查结果。
7. Change log：相对上一版的 added / metadata_changed / deprecated / replaced。
8. Limitations：本 universe 未覆盖的维度、locale 与已知偏差。

【明确不支持的主张】
- 不得声称 universe 等价于真实用户问法全集。
- 不得用 prompt 数量作为可见性指标。
- 不得声称覆盖某 prompt 就会获得该 prompt 的 AI 引用。
- 不得把 universe 当作关键词研究工具或搜索量数据来源。
- 不得输出任何单一 GEO 分数。
