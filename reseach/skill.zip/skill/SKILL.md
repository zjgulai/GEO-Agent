---
name: seo-skill-v1-6
description: 面向企业 SEO 分析与规划的模块化专家 Skill，覆盖 20 个 SEO 专业域，用于基于证据执行 SEO 审计、专项诊断、跨专业 Owner 协作、证据受限判断与增长规划。
---

# SEO Skill V1.6.0 — 正式版

本版本只修 GEO 指标 SSOT、nullable measurement 校验及 active Owner 交接一致性；canonical trace 继续使用 `canonical_v1_5` profile。指标历史值与原生调用迁移见 [1.6.0 迁移说明](MIGRATION_1.6.0.md)。正式发布范围与验证结论见 [1.6.0 发布说明](RELEASE_NOTES_1.6.0.md)。

## 目标
V1.4 不再要求 Agent 模拟复杂工作流引擎。20 个 SEO Specialist 继续负责专业判断；全局编排只保留足够证明机制执行过的最小协议。

## 唯一执行链
`Task → Plan → Specialist Reasoning → Decision / Handoff → Validate → Result`

## 五类最小对象
1. `Plan`：当前任务是什么、主路由是什么、需要哪些模块、读取哪些上下文。
2. `Evidence`：可复核观察及其证据强度。
3. `Decision`：任何需要被审计的专业/编排判断，统一用一个通用对象表达。
4. `Handoff`：跨 Owner 判断的交接；Owner 不可用时仍保留 deferred handoff。
5. `Result`：最终 Issue / Project / Recommendation / Answer。

## 核心原则
- **语义优先**：是否做对 Route、Owner、Evidence、Dedup、Dependency、Forecast 等机制，是主评分对象。
- **Trace 从简**：Trace 只需证明关键机制发生，不要求大量内部 bookkeeping 字段。
- **Schema 只管形状**：字段少写/多写不应轻易覆盖正确的专业判断；只有无法解析或缺少最小核心对象才是结构性失败。
- **Single Source of Truth**：Router、Ownership、Runtime Invariants、Schema 各司其职，不重复复制规则。
- **最小 Diff**：保持模块专业内容，不再为单个 Case 增加特殊规则。

## 运行文件与加载顺序
先读取 [最小执行协议](minimal_execution_protocol.yaml)、[路由](router.yaml)、[能力归属](ownership_registry.yaml) 与 [运行约束](runtime_invariants.yaml)。
编排说明见 [ORCHESTRATION_CORE.md](ORCHESTRATION_CORE.md)，机器可读阶段摘要见 [orchestration_core.yaml](orchestration_core.yaml)。
按路由与 Owner 的两位模块编号加载 `modules/` 中对应模块；仅加载当前任务相关专业内容。需要共用证据、页面检查或验证契约时读取 `domain_services/` 中相应服务。
[state_schema.json](state_schema.json) 定义运行输出形状；[trace_schema.json](trace_schema.json) 仅用于需要 case_id 的可选审计 Trace，不要求普通业务任务制造 case_id。
[evaluation_policy.yaml](evaluation_policy.yaml) 规定语义与 Trace 质量分层，不包含私有答案。
V1.5 运行须显式声明 `canonical_v1_5` profile，并先读 [canonical contract](canonical_trace_contract.yaml)、[canonical schema](canonical_trace_schema.json)、[module identities](module_identity_registry.yaml)、[runtime context schema](runtime_context_schema.json)；Forecast 另读 [input contract schema](forecast_input_contract_schema.json)。输出严格使用这些文件的字段与枚举，不以说明文字或别名替代结构化字段。`trace_schema.json` 仅用于旧 Trace 的基础解析；缺失 profile 或旧 profile 不进入 V1.5 canonical PASS 计数。

`semantic_review` 只可作为需要复核时的 Handoff 目标，不是 Decision Owner；即使 Dedup 需要复核，`Decision.owner` 仍填写注册 Owner。只输出当前任务所需的 Decision，不为无关专业域额外制造 Forecast 等判断。

GEO Extension 为附加层，不改变上述执行链、对象与评分原则。仅当任务显式要求 AI 可发现性、Prompt Universe、AI 引用可见性判断、**引用失败归因**、**实体/权威诊断**或**效果验证 / 实验**时才读取 `geo/GEO_CAPABILITY_MODEL.md`、`geo/GEO_MODULE_CONTRACT.yaml`、`geo/GEO_SIGNAL_REGISTRY.yaml`、`geo/GEO_METRIC_CONTRACT.yaml`、`geo/GEO_CRAWLER_TAXONOMY.yaml`（GEO-01 的 crawler/control 分类）、`geo/GEO_ENGINE_REGISTRY.yaml`（GEO-02/03 的 AI 引擎与 surface 注册表，含国内与海外生态）与 `geo/GEO_04_CITATION_FAILURE_TAXONOMY.yaml` / `geo/GEO_04_DIAGNOSTIC_METHOD.md`（GEO-04 的 failure taxonomy 与 9 维比较口径）、`geo/GEO_05_ENTITY_AUTHORITY_TAXONOMY.yaml` / `geo/GEO_05_DIAGNOSTIC_METHOD.md`（GEO-05 的 12 维实体/权威比较口径与三类证据分离）、`geo/GEO_06_MEASUREMENT_TAXONOMY.yaml` / `geo/GEO_06_MEASUREMENT_METHOD.md`（GEO-06 的窗口可比性、变化判断、归因边界与实验契约），并按 `GEO_EXTENSION_ARCHITECTURE.md` 与 `geo/GEO_MODULE_MAP.md` 的边界交接给 SEO Core Owner。GEO-01～06 已全部实现。GEO-06 只做测量、变化判断与实验契约，不得输出单一 GEO 总分，不得把国内与海外引擎或 consumer 与 API surface 合并，缺少 AI referral 数据时不得给出点值 ROI。GEO-05 只做实体/权威/来源可信度诊断，不得用 backlink 数量、Domain Authority 或 Schema/Wikipedia/媒体报道的存在代表权威。

静态检查：`python validators/validate_v1_4_architecture.py`；V1.5 Trace 检查使用工作包中的 `validate_v1_5_architecture.py` 并显式传入 profile 与来源；GEO 契约检查使用 `python geo/scripts/validate_geo_extension.py`，GEO 回归使用 `python tests/run_geo_regression.py`。Python 依赖见 [requirements.txt](requirements.txt)。
